我理解了，您希望保持原有的代码风格和结构，但应用优化后的逻辑。我会用您习惯的风格重写，保持相同的变量名、注释风格和代码结构。

```python
"""
LiveSource-Collector
IPTV直播源聚合处理工具 v1.02
功能：从多个来源获取直播源，进行分类、过滤、格式转换，生成播放列表
特点：基于0.00原版 优化名称、路径、注释、逻辑效率
作者：潇然
版本：2025-9-2
优化点：
1. 优化黑名单检查逻辑，提前过滤
2. 优化频道分发效率，减少if-else链
3. 优化URL去重逻辑
4. 保持原有代码风格和结构
"""
# ========= 模块导入区 =========
import urllib.request          # HTTP请求库，用于从网络获取直播源数据
from urllib.parse import urlparse  # URL解析工具，用于分析URL结构
import re                     # 正则表达式库，用于文本匹配和清洗
import os                     # 操作系统接口，用于文件和目录操作
from datetime import datetime, timedelta, timezone  # 日期时间处理模块
import random                 # 随机数生成，用于User-Agent轮换
import opencc                 # 简繁体转换库

import socket                 # 网络套接字库，用于网络请求
import time                   # 时间模块，用于延时和计时

# ========= 初始化输出目录 =========
os.makedirs('output', exist_ok=True)  # 创建输出目录，如果已存在则不会报错
print("创建输出目录: output")

# ========= 功能函数定义区 =========

# 简繁转换函数
def traditional_to_simplified(text: str) -> str:
    """将繁体中文转换为简体中文"""
    converter = opencc.OpenCC('t2s')
    simplified_text = converter.convert(text)
    return simplified_text

# 读取文本文件函数
def read_txt_to_array(file_name):
    """读取文本文件，返回非空行的数组"""
    try:
        with open(file_name, 'r', encoding='utf-8') as file:
            lines = file.readlines()
            lines = [line.strip() for line in lines if line.strip()]
            return lines
    except FileNotFoundError:
        print(f"File '{file_name}' not found.")
        return []
    except Exception as e:
        print(f"An error occurred: {e}")
        return []

# ========= URL处理工具函数 =========

def check_url_existence(data_list, url):
    """检查URL是否已存在于列表中"""
    urls = [item.split(',')[1] for item in data_list]
    return url not in urls

def clean_url(url):
    """清理URL，移除$符号及其后面的内容"""
    last_dollar_index = url.rfind('$')
    if last_dollar_index != -1:
        return url[:last_dollar_index]
    return url

# ========= 黑名单管理系统 =========

def load_blacklist():
    """加载所有黑名单文件，返回集合"""
    blacklist_files = [
        'assets/livesource/blacklist/blacklist_auto.txt',
        'assets/livesource/blacklist/blacklist_manual.txt'
    ]
    
    blacklist_set = set()
    
    for file_path in blacklist_files:
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                for line in file:
                    if ',' in line:
                        url = line.split(',')[1].strip()
                        cleaned_url = clean_url(url)
                        blacklist_set.add(cleaned_url)
        except FileNotFoundError:
            print(f"黑名单文件未找到: {file_path}")
    
    return blacklist_set

# 初始化黑名单（集合，提高检索速度）
blacklist_set = load_blacklist()
print(f"黑名单已加载，共 {len(blacklist_set)} 条记录")

# ========= 频道分类存储变量定义 =========
# 说明：以下是用于存储不同分类频道的列表变量

# 核心频道（优先级最高）
yangshi_lines = []      # 存储央视频道数据
weishi_lines = []       # 存储卫视频道数据

# 省级地方台频道
beijing_lines = []      # 北京
shanghai_lines = []     # 上海
guangdong_lines = []    # 广东
jiangsu_lines = []      # 江苏
zhejiang_lines = []     # 浙江
shandong_lines = []     # 山东
sichuan_lines = []      # 四川
henan_lines = []        # 河南
hunan_lines = []        # 湖南
chongqing_lines = []    # 重庆
tianjin_lines = []      # 天津
hubei_lines = []        # 湖北
anhui_lines = []        # 安徽
fujian_lines = []       # 福建
liaoning_lines = []     # 辽宁
shaanxi_lines = []      # 陕西
hebei_lines = []        # 河北
jiangxi_lines = []      # 江西
guangxi_lines = []      # 广西
yunnan_lines = []       # 云南
shanxi_lines = []       # 山西
heilongjiang_lines = [] # 黑龙江
jilin_lines = []        # 吉林
guizhou_lines = []      # 贵州
gansu_lines = []        # 甘肃
neimenggu_lines = []    # 内蒙古
xinjiang_lines = []     # 新疆
hainan_lines = []       # 海南
ningxia_lines = []      # 宁夏
qinghai_lines = []      # 青海
xizang_lines = []       # 西藏

# 港澳台频道
hongkong_lines = []    # 香港
macau_lines = []       # 澳门
minnan_lines = []      # 闽南

# 其他分类频道
digital_lines = []     # 数字
movie_lines = []       # 电影
tv_drama_lines = []    # 电视剧
documentary_lines = [] # 纪录片
cartoon_lines = []     # 动画片
radio_lines = []       # 收音机
variety_lines = []     # 综艺
huya_lines = []        # 虎牙
douyu_lines = []       # 斗鱼
commentary_lines = []  # 解说
music_lines = []       # 音乐
food_lines = []        # 美食
travel_lines = []      # 旅游
health_lines = []      # 健康
finance_lines = []     # 财经
shopping_lines = []    # 购物
game_lines = []        # 游戏
news_lines = []        # 新闻
china_lines = []       # 中国
international_lines = [] # 国际
sports_lines = []      # 体育
tyss_lines = []        # 体育赛事（2025新增）
mgss_lines = []        # 咪咕赛事（2025新增）
traditional_opera_lines = [] # 戏曲频道
spring_festival_gala_lines = [] # 历届春晚
camera_lines = []      # 景区直播（直播中国）
favorite_lines = []    # 收藏频道

# 未分类频道（兜底处理）
other_lines = []

# ========= 频道名称处理函数 =========

# 频道名称清理关键字列表
removal_list = ["_电信","电信","「LiTV」","频道","频陆","备陆","壹陆","贰陆","叁陆","肆陆","伍陆","陆陆","柒陆",
                "频晴","频粤","高清","超清","标清","斯特","粤陆","国陆","肆柒","频英","频特","频国","频壹",
                "频贰","肆贰","频测","咪咕","闽特","高特","频高","频标","汝阳","频效","国标","粤标","频推",
                "频流","粤高","频限","实时","美推","频美","（HD）","-HD","英陆","_ITV","(北美)","(HK)",
                "AKtv","「IPV4」","「IPV6」","[HD]","[BD]","[SD]","[VGA]","[超清]","4Gtv","1080","720",
                "480","HD","SD","4K","VGA","(HD)","(SD)","(4K)","(VGA)","{HD}","{SD}","{4K}","{VGA}",
                "「4gTV」","「回看」","<HD>","<SD>","<4K>","<VGA>"]

def clean_channel_name(channel_name, removal_list):
    """清理频道名称中的特定字符"""
    for item in removal_list:
        channel_name = channel_name.replace(item, "")

    # 移除末尾的'HD'
    if channel_name.endswith("HD"):
        channel_name = channel_name[:-2]

    # 移除末尾的'台'（如果频道名称长度大于3）
    if channel_name.endswith("台") and len(channel_name) > 3:
        channel_name = channel_name[:-1]

    return channel_name

def process_name_string(input_str):
    """处理频道名称字符串，统一命名格式"""
    parts = input_str.split(',')
    processed_parts = []
    for part in parts:
        processed_part = process_part(part)
        processed_parts.append(processed_part)
    return ','.join(processed_parts)

def process_part(part_str):
    """处理单个频道名称部分，统一CCTV和卫视格式"""
    # 处理CCTV频道名称
    if "CCTV" in part_str and "://" not in part_str:
        # 先剔除特定关键字
        part_str = part_str.replace("IPV6", "")
        part_str = part_str.replace("PLUS", "+")
        part_str = part_str.replace("1080", "")
        # 只保留数字、K和+号
        filtered_str = ''.join(char for char in part_str if char.isdigit() or char == 'K' or char == '+')
        # 处理特殊情况：如果没有找到频道数字，返回原名称（去掉CCTV）
        if not filtered_str.strip():
            filtered_str = part_str.replace("CCTV", "")

        # 特殊处理CCTV中的4K和8K名称
        if len(filtered_str) > 2 and re.search(r'4K|8K', filtered_str):
            filtered_str = re.sub(r'(4K|8K).*', r'\1', filtered_str)
            if len(filtered_str) > 2: 
                filtered_str = re.sub(r'(4K|8K)', r'(\1)', filtered_str)

        return "CCTV" + filtered_str 
        
    # 处理卫视频道名称
    elif "卫视" in part_str:
        pattern = r'卫视「.*」'
        result_str = re.sub(pattern, '卫视', part_str)
        return result_str

    return part_str

# ========= 文件格式处理函数 =========

def get_url_file_extension(url):
    """获取URL的文件扩展名"""
    parsed_url = urlparse(url)
    path = parsed_url.path
    extension = os.path.splitext(path)[1]
    return extension

def convert_m3u_to_txt(m3u_content):
    """将M3U格式转换为TXT格式（频道名称,URL）"""
    lines = m3u_content.split('\n')
    txt_lines = []
    channel_name = ""

    for line in lines:
        if line.startswith("#EXTM3U"):
            continue
        if line.startswith("#EXTINF"):
            channel_name = line.split(',')[-1].strip()
        elif line.startswith("http") or line.startswith("rtmp") or line.startswith("p3p"):
            txt_lines.append(f"{channel_name},{line.strip()}")

        # 处理格式为TXT但后缀为M3U的文件
        if "#genre#" not in line and "," in line and "://" in line:
            pattern = r'^[^,]+,[^\s]+://[^\s]+$'
            if bool(re.match(pattern, line)):
                txt_lines.append(line)

    return '\n'.join(txt_lines)

# ========= 频道字典文件读取 =========

current_directory = os.getcwd()

# 读取核心频道字典
yangshi_dictionary = read_txt_to_array('assets/livesource/主频道/CCTV.txt')
weishi_dictionary = read_txt_to_array('assets/livesource/主频道/卫视.txt')

# 读取省级地方台字典
beijing_dictionary = read_txt_to_array('assets/livesource/地方台/北京.txt')
shanghai_dictionary = read_txt_to_array('assets/livesource/地方台/上海.txt')
guangdong_dictionary = read_txt_to_array('assets/livesource/地方台/广东.txt')
jiangsu_dictionary = read_txt_to_array('assets/livesource/地方台/江苏.txt')
zhejiang_dictionary = read_txt_to_array('assets/livesource/地方台/浙江.txt')
shandong_dictionary = read_txt_to_array('assets/livesource/地方台/山东.txt')
sichuan_dictionary = read_txt_to_array('assets/livesource/地方台/四川.txt')
henan_dictionary = read_txt_to_array('assets/livesource/地方台/河南.txt')
hunan_dictionary = read_txt_to_array('assets/livesource/地方台/湖南.txt')
chongqing_dictionary = read_txt_to_array('assets/livesource/地方台/重庆.txt')
tianjin_dictionary = read_txt_to_array('assets/livesource/地方台/天津.txt')
hubei_dictionary = read_txt_to_array('assets/livesource/地方台/湖北.txt')
anhui_dictionary = read_txt_to_array('assets/livesource/地方台/安徽.txt')
fujian_dictionary = read_txt_to_array('assets/livesource/地方台/福建.txt')
liaoning_dictionary = read_txt_to_array('assets/livesource/地方台/辽宁.txt')
shaanxi_dictionary = read_txt_to_array('assets/livesource/地方台/陕西.txt')
hebei_dictionary = read_txt_to_array('assets/livesource/地方台/河北.txt')
jiangxi_dictionary = read_txt_to_array('assets/livesource/地方台/江西.txt')
guangxi_dictionary = read_txt_to_array('assets/livesource/地方台/广西.txt')
yunnan_dictionary = read_txt_to_array('assets/livesource/地方台/云南.txt')
shanxi_dictionary = read_txt_to_array('assets/livesource/地方台/山西.txt')
heilongjiang_dictionary = read_txt_to_array('assets/livesource/地方台/黑龙江.txt')
jilin_dictionary = read_txt_to_array('assets/livesource/地方台/吉林.txt')
guizhou_dictionary = read_txt_to_array('assets/livesource/地方台/贵州.txt')
gansu_dictionary = read_txt_to_array('assets/livesource/地方台/甘肃.txt')
neimenggu_dictionary = read_txt_to_array('assets/livesource/地方台/内蒙.txt')
xinjiang_dictionary = read_txt_to_array('assets/livesource/地方台/新疆.txt')
hainan_dictionary = read_txt_to_array('assets/livesource/地方台/海南.txt')
ningxia_dictionary = read_txt_to_array('assets/livesource/地方台/宁夏.txt')
qinghai_dictionary = read_txt_to_array('assets/livesource/地方台/青海.txt')
xizang_dictionary = read_txt_to_array('assets/livesource/地方台/西藏.txt')

# 读取港澳台地区字典
hongkong_dictionary = read_txt_to_array('assets/livesource/地方台/香港.txt')
macau_dictionary = read_txt_to_array('assets/livesource/地方台/澳门.txt')
minnan_dictionary = read_txt_to_array('assets/livesource/地方台/闽南.txt')

# 读取其他分类字典
digital_dictionary = read_txt_to_array('assets/livesource/主频道/数字.txt')
movie_dictionary = read_txt_to_array('assets/livesource/主频道/电影.txt')
tv_drama_dictionary = read_txt_to_array('assets/livesource/主频道/电视剧.txt')
documentary_dictionary = read_txt_to_array('assets/livesource/主频道/纪录片.txt')
cartoon_dictionary = read_txt_to_array('assets/livesource/主频道/动画片.txt')
radio_dictionary = read_txt_to_array('assets/livesource/主频道/收音机.txt')
variety_dictionary = read_txt_to_array('assets/livesource/主频道/综艺.txt')
huya_dictionary = read_txt_to_array('assets/livesource/主频道/虎牙.txt')
douyu_dictionary = read_txt_to_array('assets/livesource/主频道/斗鱼.txt')
commentary_dictionary = read_txt_to_array('assets/livesource/主频道/解说.txt')
music_dictionary = read_txt_to_array('assets/livesource/主频道/音乐.txt')
food_dictionary = read_txt_to_array('assets/livesource/主频道/美食.txt')
travel_dictionary = read_txt_to_array('assets/livesource/主频道/旅游.txt')
health_dictionary = read_txt_to_array('assets/livesource/主频道/健康.txt')
finance_dictionary = read_txt_to_array('assets/livesource/主频道/财经.txt')
shopping_dictionary = read_txt_to_array('assets/livesource/主频道/购物.txt')
game_dictionary = read_txt_to_array('assets/livesource/主频道/游戏.txt')
news_dictionary = read_txt_to_array('assets/livesource/主频道/新闻.txt')
china_dictionary = read_txt_to_array('assets/livesource/主频道/中国.txt')
international_dictionary = read_txt_to_array('assets/livesource/主频道/国际.txt')
sports_dictionary = read_txt_to_array('assets/livesource/主频道/体育.txt')
tyss_dictionary = read_txt_to_array('assets/livesource/主频道/体育赛事.txt')
mgss_dictionary = read_txt_to_array('assets/livesource/主频道/咪咕赛事.txt')
traditional_opera_dictionary = read_txt_to_array('assets/livesource/主频道/戏曲.txt')
spring_festival_gala_dictionary = read_txt_to_array('assets/livesource/主频道/春晚.txt')
camera_dictionary = read_txt_to_array('assets/livesource/主频道/直播中国.txt')
favorite_dictionary = read_txt_to_array('assets/livesource/主频道/收藏频道.txt')

# ========= 频道名称纠错处理 =========

def load_corrections_name(filename):
    """加载频道名称纠错字典"""
    corrections = {}
    with open(filename, 'r', encoding='utf-8') as f:
        for line in f:
            if not line.strip():
                continue
            parts = line.strip().split(',')
            correct_name = parts[0]
            for name in parts[1:]:
                corrections[name] = correct_name
    return corrections

# 读取纠错文件
corrections_name = load_corrections_name('assets/livesource/corrections_name.txt')

def correct_name_data(corrections, data):
    """使用纠错字典修正频道名称"""
    corrected_data = []
    for line in data:
        line = line.strip()
        if ',' not in line:
            continue

        name, url = line.split(',', 1)

        if name in corrections and name != corrections[name]:
            name = corrections[name]

        corrected_data.append(f"{name},{url}")
    return corrected_data

def sort_data(order, data):
    """按指定顺序对数据进行排序"""
    order_dict = {name: i for i, name in enumerate(order)}

    def sort_key(line):
        name = line.split(',')[0]
        return order_dict.get(name, len(order))

    sorted_data = sorted(data, key=sort_key)
    return sorted_data

# ========= 优化后的频道分发系统 =========

# 已处理的URL集合，用于全局去重
processed_urls = set()

# 分类映射字典，提高查找效率
category_mapping = {}

def build_category_mapping():
    """构建频道分类映射字典"""
    mapping = {}
    
    # 央视频道映射
    for name in yangshi_dictionary:
        if "CCTV" in name:
            mapping[name] = "yangshi"
    
    # 卫视频道映射
    for name in weishi_dictionary:
        mapping[name] = "weishi"
    
    # 地方台频道映射
    local_channels = [
        (beijing_dictionary, "beijing"),
        (shanghai_dictionary, "shanghai"),
        (guangdong_dictionary, "guangdong"),
        (jiangsu_dictionary, "jiangsu"),
        (zhejiang_dictionary, "zhejiang"),
        (shandong_dictionary, "shandong"),
        (sichuan_dictionary, "sichuan"),
        (henan_dictionary, "henan"),
        (hunan_dictionary, "hunan"),
        (chongqing_dictionary, "chongqing"),
        (tianjin_dictionary, "tianjin"),
        (hubei_dictionary, "hubei"),
        (anhui_dictionary, "anhui"),
        (fujian_dictionary, "fujian"),
        (liaoning_dictionary, "liaoning"),
        (shaanxi_dictionary, "shaanxi"),
        (hebei_dictionary, "hebei"),
        (jiangxi_dictionary, "jiangxi"),
        (guangxi_dictionary, "guangxi"),
        (yunnan_dictionary, "yunnan"),
        (shanxi_dictionary, "shanxi"),
        (heilongjiang_dictionary, "heilongjiang"),
        (jilin_dictionary, "jilin"),
        (guizhou_dictionary, "guizhou"),
        (gansu_dictionary, "gansu"),
        (neimenggu_dictionary, "neimenggu"),
        (xinjiang_dictionary, "xinjiang"),
        (hainan_dictionary, "hainan"),
        (ningxia_dictionary, "ningxia"),
        (qinghai_dictionary, "qinghai"),
        (xizang_dictionary, "xizang"),
        (hongkong_dictionary, "hongkong"),
        (macau_dictionary, "macau"),
        (minnan_dictionary, "minnan")
    ]
    
    for dictionary, category in local_channels:
        for name in dictionary:
            mapping[name] = category
    
    # 其他分类映射
    other_channels = [
        (digital_dictionary, "digital"),
        (movie_dictionary, "movie"),
        (tv_drama_dictionary, "tv_drama"),
        (documentary_dictionary, "documentary"),
        (cartoon_dictionary, "cartoon"),
        (radio_dictionary, "radio"),
        (variety_dictionary, "variety"),
        (huya_dictionary, "huya"),
        (douyu_dictionary, "douyu"),
        (commentary_dictionary, "commentary"),
        (music_dictionary, "music"),
        (food_dictionary, "food"),
        (travel_dictionary, "travel"),
        (health_dictionary, "health"),
        (finance_dictionary, "finance"),
        (shopping_dictionary, "shopping"),
        (game_dictionary, "game"),
        (news_dictionary, "news"),
        (china_dictionary, "china"),
        (international_dictionary, "international"),
        (sports_dictionary, "sports"),
        (traditional_opera_dictionary, "traditional_opera"),
        (spring_festival_gala_dictionary, "spring_festival_gala"),
        (camera_dictionary, "camera"),
        (favorite_dictionary, "favorite")
    ]
    
    for dictionary, category in other_channels:
        for name in dictionary:
            mapping[name] = category
    
    return mapping

# 构建分类映射
category_mapping = build_category_mapping()

def get_channel_category(channel_name):
    """获取频道所属分类"""
    # 先尝试直接匹配
    if channel_name in category_mapping:
        return category_mapping[channel_name]
    
    # 尝试匹配体育赛事关键字
    for keyword in tyss_dictionary:
        if keyword in channel_name:
            return "tyss"
    
    # 尝试匹配咪咕赛事关键字
    for keyword in mgss_dictionary:
        if keyword in channel_name:
            return "mgss"
    
    # 默认返回其他分类
    return "other"

def add_channel_to_category(category, line):
    """添加频道到指定分类"""
    if category == "yangshi":
        yangshi_lines.append(process_name_string(line.strip()))
    elif category == "weishi":
        weishi_lines.append(process_name_string(line.strip()))
    elif category == "beijing":
        beijing_lines.append(process_name_string(line.strip()))
    elif category == "shanghai":
        shanghai_lines.append(process_name_string(line.strip()))
    elif category == "guangdong":
        guangdong_lines.append(process_name_string(line.strip()))
    elif category == "jiangsu":
        jiangsu_lines.append(process_name_string(line.strip()))
    elif category == "zhejiang":
        zhejiang_lines.append(process_name_string(line.strip()))
    elif category == "shandong":
        shandong_lines.append(process_name_string(line.strip()))
    elif category == "sichuan":
        sichuan_lines.append(process_name_string(line.strip()))
    elif category == "henan":
        henan_lines.append(process_name_string(line.strip()))
    elif category == "hunan":
        hunan_lines.append(process_name_string(line.strip()))
    elif category == "chongqing":
        chongqing_lines.append(process_name_string(line.strip()))
    elif category == "tianjin":
        tianjin_lines.append(process_name_string(line.strip()))
    elif category == "hubei":
        hubei_lines.append(process_name_string(line.strip()))
    elif category == "anhui":
        anhui_lines.append(process_name_string(line.strip()))
    elif category == "fujian":
        fujian_lines.append(process_name_string(line.strip()))
    elif category == "liaoning":
        liaoning_lines.append(process_name_string(line.strip()))
    elif category == "shaanxi":
        shaanxi_lines.append(process_name_string(line.strip()))
    elif category == "hebei":
        hebei_lines.append(process_name_string(line.strip()))
    elif category == "jiangxi":
        jiangxi_lines.append(process_name_string(line.strip()))
    elif category == "guangxi":
        guangxi_lines.append(process_name_string(line.strip()))
    elif category == "yunnan":
        yunnan_lines.append(process_name_string(line.strip()))
    elif category == "shanxi":
        shanxi_lines.append(process_name_string(line.strip()))
    elif category == "heilongjiang":
        heilongjiang_lines.append(process_name_string(line.strip()))
    elif category == "jilin":
        jilin_lines.append(process_name_string(line.strip()))
    elif category == "guizhou":
        guizhou_lines.append(process_name_string(line.strip()))
    elif category == "gansu":
        gansu_lines.append(process_name_string(line.strip()))
    elif category == "neimenggu":
        neimenggu_lines.append(process_name_string(line.strip()))
    elif category == "xinjiang":
        xinjiang_lines.append(process_name_string(line.strip()))
    elif category == "hainan":
        hainan_lines.append(process_name_string(line.strip()))
    elif category == "ningxia":
        ningxia_lines.append(process_name_string(line.strip()))
    elif category == "qinghai":
        qinghai_lines.append(process_name_string(line.strip()))
    elif category == "xizang":
        xizang_lines.append(process_name_string(line.strip()))
    elif category == "hongkong":
        hongkong_lines.append(process_name_string(line.strip()))
    elif category == "macau":
        macau_lines.append(process_name_string(line.strip()))
    elif category == "minnan":
        minnan_lines.append(process_name_string(line.strip()))
    elif category == "digital":
        digital_lines.append(process_name_string(line.strip()))
    elif category == "movie":
        movie_lines.append(process_name_string(line.strip()))
    elif category == "tv_drama":
        tv_drama_lines.append(process_name_string(line.strip()))
    elif category == "documentary":
        documentary_lines.append(process_name_string(line.strip()))
    elif category == "cartoon":
        cartoon_lines.append(process_name_string(line.strip()))
    elif category == "radio":
        radio_lines.append(process_name_string(line.strip()))
    elif category == "variety":
        variety_lines.append(process_name_string(line.strip()))
    elif category == "huya":
        huya_lines.append(process_name_string(line.strip()))
    elif category == "douyu":
        douyu_lines.append(process_name_string(line.strip()))
    elif category == "commentary":
        commentary_lines.append(process_name_string(line.strip()))
    elif category == "music":
        music_lines.append(process_name_string(line.strip()))
    elif category == "food":
        food_lines.append(process_name_string(line.strip()))
    elif category == "travel":
        travel_lines.append(process_name_string(line.strip()))
    elif category == "health":
        health_lines.append(process_name_string(line.strip()))
    elif category == "finance":
        finance_lines.append(process_name_string(line.strip()))
    elif category == "shopping":
        shopping_lines.append(process_name_string(line.strip()))
    elif category == "game":
        game_lines.append(process_name_string(line.strip()))
    elif category == "news":
        news_lines.append(process_name_string(line.strip()))
    elif category == "china":
        china_lines.append(process_name_string(line.strip()))
    elif category == "international":
        international_lines.append(process_name_string(line.strip()))
    elif category == "sports":
        sports_lines.append(process_name_string(line.strip()))
    elif category == "tyss":
        tyss_lines.append(process_name_string(line.strip()))
    elif category == "mgss":
        mgss_lines.append(process_name_string(line.strip()))
    elif category == "traditional_opera":
        traditional_opera_lines.append(process_name_string(line.strip()))
    elif category == "spring_festival_gala":
        spring_festival_gala_lines.append(process_name_string(line.strip()))
    elif category == "camera":
        camera_lines.append(process_name_string(line.strip()))
    elif category == "favorite":
        favorite_lines.append(process_name_string(line.strip()))
    elif category == "other":
        other_lines.append(line.strip())

def process_channel_line(line):
    """处理单行频道数据，进行分类分发（优化版）"""
    # 检查是否为有效的频道行
    if "#genre#" not in line and "#EXTINF:" not in line and "," in line and "://" in line:
        # 分割频道名称和URL
        channel_name = line.split(',')[0].strip()
        channel_address = line.split(',')[1].strip()
        
        # 清理频道名称
        channel_name = clean_channel_name(channel_name, removal_list)
        channel_name = traditional_to_simplified(channel_name)
        
        # 应用名称纠错
        if channel_name in corrections_name:
            channel_name = corrections_name[channel_name]
        
        # 清理URL
        channel_address = clean_url(channel_address)
        
        # 检查黑名单（优化：提前过滤）
        if channel_address in blacklist_set:
            return
        
        # 检查URL是否已处理（全局去重）
        if channel_address in processed_urls:
            return
        processed_urls.add(channel_address)
        
        # 重新组合行
        processed_line = f"{channel_name},{channel_address}"
        
        # 获取频道分类
        category = get_channel_category(channel_name)
        
        # 添加到对应分类
        add_channel_to_category(category, processed_line)

# ========= HTTP请求处理函数 =========

def get_random_user_agent():
    """随机获取User-Agent，用于HTTP请求头"""
    USER_AGENTS = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.82 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36",
    ]
    return random.choice(USER_AGENTS)

def process_url(url):
    """处理单个URL，获取并解析直播源数据"""
    try:
        # 记录处理的URL
        other_lines.append("◆◆◆　" + url)
        
        # 创建HTTP请求
        req = urllib.request.Request(url)
        req.add_header('User-Agent', get_random_user_agent())

        # 发送HTTP请求并获取响应
        with urllib.request.urlopen(req, timeout=10) as response:
            data = response.read()
            text = data.decode('utf-8')
            text = text.strip()

            # 检查是否为M3U格式文件
            is_m3u = text.startswith("#EXTM3U") or text.startswith("#EXTINF")
            if get_url_file_extension(url) == ".m3u" or get_url_file_extension(url) == ".m3u8" or is_m3u:
                text = convert_m3u_to_txt(text)

            # 逐行处理内容
            lines = text.split('\n')
            print(f"URL: {url}, 行数: {len(lines)}")
            
            for line in lines:
                # 过滤无效行
                if "#genre#" not in line and "," in line and "://" in line and "tvbus://" not in line and "/udp/" not in line:
                    # 分割频道名称和URL
                    channel_name, channel_address = line.split(',', 1)
                    
                    # 处理加速源（包含#号分隔的多个URL）
                    if "#" not in channel_address:
                        process_channel_line(line)
                    else: 
                        # 加速源，按#号分割为多个URL分别处理
                        url_list = channel_address.split('#')
                        for channel_url in url_list:
                            if channel_url.strip():
                                newline = f'{channel_name},{channel_url}'
                                process_channel_line(newline)

            # 每个URL处理完成后添加空行分隔
            other_lines.append('')

    except Exception as e:
        print(f"处理URL时发生错误 {url}: {e}")

# ========= 主处理流程 =========

# 记录执行开始时间
timestart = datetime.now()
print(f"开始时间: {datetime.now().strftime('%Y%m%d_%H_%M_%S')}")

# 读取URL列表
urls = read_txt_to_array('assets/livesource/urls-daily.txt')

# 处理每个URL
for url in urls:
    if url.startswith("http"):
        # 处理日期变量
        if "{MMdd}" in url:
            current_date_str = datetime.now().strftime("%m%d")
            url = url.replace("{MMdd}", current_date_str)

        if "{MMdd-1}" in url:
            yesterday_date_str = (datetime.now() - timedelta(days=1)).strftime("%m%d")
            url = url.replace("{MMdd-1}", yesterday_date_str)
            
        print(f"处理URL: {url}")
        process_url(url)

# ========= 白名单处理 =========

print(f"添加白名单...")
whitelist_auto_lines = read_txt_to_array('assets/livesource/blacklist/whitelist_auto.txt')
for whitelist_line in whitelist_auto_lines:
    if "#genre#" not in whitelist_line and "," in whitelist_line and "://" in whitelist_line:
        whitelist_parts = whitelist_line.split(",")
        try:
            response_time = float(whitelist_parts[0].replace("ms", ""))
        except ValueError:
            response_time = 60000
        
        # 只添加响应时间小于2秒的高质量源
        if response_time < 2000:
            process_channel_line(",".join(whitelist_parts[1:]))

# ========= HTTP响应测试函数 =========

def get_http_response(url, timeout=8, retries=2, backoff_factor=1.0):
    """获取HTTP响应，支持重试机制"""
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'
    }
    
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=timeout) as response:
                data = response.read()
                return data.decode('utf-8')
        except urllib.error.HTTPError as e:
            print(f"[HTTPError] Code: {e.code}, URL: {url}")
            break
        except urllib.error.URLError as e:
            print(f"[URLError] Reason: {e.reason}, Attempt: {attempt + 1}")
        except socket.timeout:
            print(f"[Timeout] URL: {url}, Attempt: {attempt + 1}")
        except Exception as e:
            print(f"[Exception] {type(e).__name__}: {e}, Attempt: {attempt + 1}")
        
        if attempt < retries - 1:
            time.sleep(backoff_factor * (2 ** attempt))

    return None

# ========= 体育赛事日期格式化 =========

def normalize_date_to_md(text):
    """将各种日期格式统一为MM-DD格式"""
    text = text.strip()

    def format_md(m):
        month = int(m.group(1))
        day = int(m.group(2))
        after = m.group(3) or ''
        if not after.startswith(' '):
            after = ' ' + after
        return f"{month:02d}-{day:02d}{after}"

    # MM/DD或M/D格式
    text = re.sub(r'^0?(\d{1,2})/0?(\d{1,2})(.*)', format_md, text)

    # YYYY-MM-DD或类似格式
    text = re.sub(r'^\d{4}-0?(\d{1,2})-0?(\d{1,2})(.*)', format_md, text)

    # 中文M月D日格式
    text = re.sub(r'^0?(\d{1,2})月0?(\d{1,2})日(.*)', format_md, text)

    return text

# 对体育赛事日期进行统一格式化
normalized_tyss_lines = [normalize_date_to_md(s) for s in tyss_lines]

# ========= AKTV特殊处理 =========

aktv_lines = []
aktv_url = "https://aktv.space/live.m3u"

# 尝试从网络获取AKTV源
aktv_text = get_http_response(aktv_url)
if aktv_text:
    print("AKTV成功获取内容")
    aktv_text = convert_m3u_to_txt(aktv_text)
    aktv_lines = aktv_text.strip().split('\n')
else:
    print("AKTV请求失败，从本地获取！")
    aktv_lines = read_txt_to_array('assets/livesource/手工区/AKTV.txt')

# 处理AKTV数据
for line in aktv_lines:
    process_channel_line(line)

# ========= 数据过滤函数 =========

def filter_lines(lines, exclude_keywords):
    """过滤包含特定关键词的行"""
    return [line for line in lines if not any(keyword in line for keyword in exclude_keywords)]

# ========= 生成HTML播放列表 =========

def generate_playlist_html(data_list, output_file='playlist.html'):
    """生成HTML格式的播放列表"""
    html_head = '''
    <!DOCTYPE html>
    <html lang="zh">
    <head>
        <meta charset="UTF-8">        
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-6061710286208572"
     crossorigin="anonymous"></script>
        <!-- Setup Google Analytics -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=G-BS1Z4F5BDN"></script>
        <script> 
        window.dataLayer = window.dataLayer || []; 
        function gtag(){dataLayer.push(arguments);} 
        gtag('js', new Date()); 
        gtag('config', 'G-BS1Z4F5BDN'); 
        </script>
        <title>最新体育赛事</title>
        <style>
            body { font-family: sans-serif; padding: 20px; background: #f9f9f9; }
            .item { margin-bottom: 20px; padding: 12px; background: #fff; border-radius: 8px;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.06); }
            .title { font-weight: bold; font-size: 1.1em; color: #333; margin-bottom: 5px; }
            .url-wrapper { display: flex; align-items: center; gap: 10px; }
            .url {
                max-width: 80%;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                font-size: 0.9em;
                color: #555;
                background: #f0f0f0;
                padding: 6px;
                border-radius: 4px;
                flex-grow: 1;
            }
            .copy-btn {
                background-color: #007BFF;
                border: none;
                color: white;
                padding: 6px 10px;
                border-radius: 4px;
                cursor: pointer;
                font-size: 0.8em;
            }
            .copy-btn:hover {
                background-color: #0056b3;
            }
        </style>
    </head>
    <body>
    <h2>📋 最新体育赛事列表</h2>
    '''

    html_body = ''
    for idx, entry in enumerate(data_list):
        if ',' not in entry:
            continue
        info, url = entry.split(',', 1)
        url_id = f"url_{idx}"
        html_body += f'''
        <div class="item">
            <div class="title">🕒 {info}</div>
            <div class="url-wrapper">
                <div class="url" id="{url_id}">{url}</div>
                <button class="copy-btn" onclick="copyToClipboard('{url_id}')">复制</button>
            </div>
        </div>
        '''

    html_tail = '''
    <script>
        function copyToClipboard(id) {
            const el = document.getElementById(id);
            const text = el.textContent;
            navigator.clipboard.writeText(text).then(() => {
                alert("已复制链接！");
            }).catch(err => {
                alert("复制失败: " + err);
            });
        }
    </script>
    </body>
    </html>
    '''

    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(html_head + html_body + html_tail)
    print(f"✅ 网页已生成：{output_file}")

# ========= 体育赛事专用排序 =========

def custom_tyss_sort(lines):
    """体育赛事专用排序：数字开头倒序排在上面，其他升序排在下面"""
    digit_prefix = []
    others = []

    for line in lines:
        name_part = line.split(',')[0].strip()
        if name_part and name_part[0].isdigit():
            digit_prefix.append(line)
        else:
            others.append(line)

    digit_prefix_sorted = sorted(digit_prefix, reverse=True)
    others_sorted = sorted(others)

    return digit_prefix_sorted + others_sorted

# ========= 体育赛事数据过滤和生成 =========

keywords_to_exclude_tiyu_txt = ["玉玉软件", "榴芒电视", "公众号", "麻豆", "「回看」"]
keywords_to_exclude_tiyu = ["玉玉软件", "榴芒电视", "公众号", "咪视通", "麻豆", "「回看」"]

# 应用过滤和排序
normalized_tyss_lines = filter_lines(normalized_tyss_lines, keywords_to_exclude_tiyu_txt)
normalized_tyss_lines = custom_tyss_sort(set(normalized_tyss_lines))
filtered_tyss_lines = filter_lines(normalized_tyss_lines, keywords_to_exclude_tiyu)

# 生成HTML页面
generate_playlist_html(filtered_tyss_lines, 'output/tiyu.html')

# 生成TXT文件
with open('output/tiyu.txt', 'w', encoding='utf-8') as f:
    for line in filtered_tyss_lines:
        f.write(line + '\n')
print(f"体育赛事文本已保存到文件: tiyu.txt")

# ========= 随机URL获取函数 =========

def get_random_url(file_path):
    """从文件中随机获取一个URL"""
    urls = []
    with open(file_path, 'r', encoding='utf-8') as file:
        for line in file:
            url = line.strip().split(',')[-1]
            urls.append(url)    
    return random.choice(urls) if urls else None

# ========= 今日推荐和版本信息 =========

# 获取北京时间
utc_time = datetime.now(timezone.utc)
beijing_time = utc_time + timedelta(hours=8)
formatted_time = beijing_time.strftime("%Y%m%d %H:%M:%S")

# 生成今日推荐信息
MTV1 = "💯推荐," + get_random_url('assets/livesource/手工区/今日推荐.txt')
MTV2 = "🤫低调," + get_random_url('assets/livesource/手工区/今日推荐.txt')
MTV3 = "🟢使用," + get_random_url('assets/livesource/手工区/今日推荐.txt')
MTV4 = "⚠️禁止," + get_random_url('assets/livesource/手工区/今日推荐.txt')
MTV5 = "🚫贩卖," + get_random_url('assets/livesource/手工区/今日推荐.txt')

# 生成版本信息
version = formatted_time + "," + get_random_url('assets/livesource/手工区/今日推台.txt')
about = "👨潇然," + get_random_url('assets/livesource/手工区/今日推台.txt')

# ========= 手工区数据补充 =========

print(f"处理手工区...")
# 补充手工维护的频道数据
zhejiang_lines = zhejiang_lines + read_txt_to_array('assets/livesource/手工区/浙江频道.txt')
guangdong_lines = guangdong_lines + read_txt_to_array('assets/livesource/手工区/广东频道.txt')
hubei_lines = hubei_lines + read_txt_to_array('assets/livesource/手工区/湖北频道.txt')
shanghai_lines = shanghai_lines + read_txt_to_array('assets/livesource/手工区/上海频道.txt')
jiangsu_lines = jiangsu_lines + read_txt_to_array('assets/livesource/手工区/江苏频道.txt')

# ========= 生成最终播放列表文件 =========

# 完整版播放列表（包含所有分类）
all_lines_full = ["🌐央视频道,#genre#"] + sort_data(yangshi_dictionary,correct_name_data(corrections_name,yangshi_lines)) + ['\n'] + \
        ["📡卫视频道,#genre#"] + sort_data(weishi_dictionary,correct_name_data(corrections_name,weishi_lines)) + ['\n'] + \
        ["🏛️北京频道,#genre#"] + sort_data(beijing_dictionary,correct_name_data(corrections_name,beijing_lines)) + ['\n'] + \
        ["🏙️上海频道,#genre#"] + sort_data(shanghai_dictionary,correct_name_data(corrections_name,shanghai_lines)) + ['\n'] + \
        ["🐯广东频道,#genre#"] + sort_data(guangdong_dictionary,correct_name_data(corrections_name,guangdong_lines)) + ['\n'] + \
        ["🎐江苏频道,#genre#"] + sort_data(jiangsu_dictionary,correct_name_data(corrections_name,jiangsu_lines)) + ['\n'] + \
        ["🧵浙江频道,#genre#"] + sort_data(zhejiang_dictionary,correct_name_data(corrections_name,zhejiang_lines)) + ['\n'] + \
        ["⛰️山东频道,#genre#"] + sort_data(shandong_dictionary,correct_name_data(corrections_name,shandong_lines)) + ['\n'] + \
        ["🐼四川频道,#genre#"] + sort_data(sichuan_dictionary,correct_name_data(corrections_name,sichuan_lines)) + ['\n'] + \
        ["🐘河南频道,#genre#"] + sort_data(henan_dictionary,correct_name_data(corrections_name,henan_lines)) + ['\n'] + \
        ["🌶️湖南频道,#genre#"] + sort_data(hunan_dictionary,correct_name_data(corrections_name,hunan_lines)) + ['\n'] + \
        ["🏞️重庆频道,#genre#"] + sort_data(chongqing_dictionary,correct_name_data(corrections_name,chongqing_lines)) + ['\n'] + \
        ["🚢天津频道,#genre#"] + sort_data(tianjin_dictionary,correct_name_data(corrections_name,tianjin_lines)) + ['\n'] + \
        ["🏯湖北频道,#genre#"] + sort_data(hubei_dictionary,correct_name_data(corrections_name,hubei_lines)) + ['\n'] + \
        ["🌾安徽频道,#genre#"] + sort_data(anhui_dictionary,correct_name_data(corrections_name,anhui_lines)) + ['\n'] + \
        ["🌊福建频道,#genre#"] + sort_data(fujian_dictionary,correct_name_data(corrections_name,fujian_lines)) + ['\n'] + \
        ["⛰️辽宁频道,#genre#"] + sort_data(liaoning_dictionary,correct_name_data(corrections_name,liaoning_lines)) + ['\n'] + \
        ["🔥陕西频道,#genre#"] + sort_data(shaanxi_dictionary,correct_name_data(corrections_name,shaanxi_lines)) + ['\n'] + \
        ["⛩️河北频道,#genre#"] + sort_data(hebei_dictionary,correct_name_data(corrections_name,hebei_lines)) + ['\n'] + \
        ["🔥江西频道,#genre#"] + sort_data(jiangxi_dictionary,correct_name_data(corrections_name,jiangxi_lines)) + ['\n'] + \
        ["💃广西频道,#genre#"] + sort_data(guangxi_dictionary,correct_name_data(corrections_name,guangxi_lines)) + ['\n'] + \
        ["☁️云南频道,#genre#"] + sort_data(yunnan_dictionary,correct_name_data(corrections_name,yunnan_lines)) + ['\n'] + \
        ["🏮山西频道,#genre#"] + sort_data(shanxi_dictionary,correct_name_data(corrections_name,shanxi_lines)) + ['\n'] + \
        ["🐻黑·龙·江,#genre#"] + sort_data(heilongjiang_dictionary,correct_name_data(corrections_name,heilongjiang_lines)) + ['\n'] + \
        ["🎎吉林频道,#genre#"] + sort_data(jilin_dictionary,correct_name_data(corrections_name,jilin_lines)) + ['\n'] + \
        ["⛰️贵州频道,#genre#"] + sort_data(guizhou_dictionary,correct_name_data(corrections_name,guizhou_lines)) + ['\n'] + \
        ["🐫甘肃频道,#genre#"] + sort_data(gansu_dictionary,correct_name_data(corrections_name,gansu_lines)) + ['\n'] + \
        ["🐮内·蒙·古,#genre#"] + sort_data(neimenggu_dictionary,correct_name_data(corrections_name,neimenggu_lines)) + ['\n'] + \
        ["🍇新疆频道,#genre#"] + sort_data(xinjiang_dictionary,correct_name_data(corrections_name,xinjiang_lines)) + ['\n'] + \
        ["🏝️海南频道,#genre#"] + sort_data(hainan_dictionary,correct_name_data(corrections_name,hainan_lines)) + ['\n'] + \
        ["🕌宁夏频道,#genre#"] + sort_data(ningxia_dictionary,correct_name_data(corrections_name,ningxia_lines)) + ['\n'] + \
        ["🐑青海频道,#genre#"] + sort_data(qinghai_dictionary,correct_name_data(corrections_name,qinghai_lines)) + ['\n'] + \
        ["🐐西藏频道,#genre#"] + sort_data(xizang_dictionary,correct_name_data(corrections_name,xizang_lines)) + ['\n'] + \
        ["🇭🇰香港频道,#genre#"] + sort_data(hongkong_dictionary,correct_name_data(corrections_name,hongkong_lines)) + ['\n'] + \
        ["🇲🇴澳门频道,#genre#"] + sort_data(macau_dictionary,correct_name_data(corrections_name,macau_lines)) + ['\n'] + \
        ["🇨🇳闽南频道,#genre#"] + sort_data(minnan_dictionary,correct_name_data(corrections_name,minnan_lines)) + ['\n'] + \
        ["🔢数字频道,#genre#"] + sort_data(digital_dictionary,correct_name_data(corrections_name,digital_lines)) + ['\n'] + \
        ["🎬电影频道,#genre#"] + sort_data(movie_dictionary,correct_name_data(corrections_name,movie_lines)) + ['\n'] + \
        ["📺电·视·剧,#genre#"] + sort_data(tv_drama_dictionary,correct_name_data(corrections_name,tv_drama_lines)) + ['\n'] + \
        ["🎥纪·录·片,#genre#"] + sort_data(documentary_dictionary,correct_name_data(corrections_name,documentary_lines)) + ['\n'] + \
        ["🐱动·画·片,#genre#"] + sort_data(cartoon_dictionary,correct_name_data(corrections_name,cartoon_lines)) + ['\n'] + \
        ["📻收·音·机,#genre#"] + sort_data(radio_dictionary,correct_name_data(corrections_name,radio_lines)) + ['\n'] + \
        ["🎭综艺频道,#genre#"] + sort_data(variety_dictionary,correct_name_data(corrections_name,variety_lines)) + ['\n'] + \
        ["🐯虎牙直播,#genre#"] + sort_data(huya_dictionary,correct_name_data(corrections_name,huya_lines)) + ['\n'] + \
        ["🐠斗鱼直播,#genre#"] + sort_data(douyu_dictionary,correct_name_data(corrections_name,douyu_lines)) + ['\n'] + \
        ["🎤解说频道,#genre#"] + sort_data(commentary_dictionary,correct_name_data(corrections_name,commentary_lines)) + ['\n'] + \
        ["🎵音乐频道,#genre#"] + sort_data(music_dictionary,correct_name_data(corrections_name,music_lines)) + ['\n'] + \
        ["🍜美食频道,#genre#"] + sort_data(food_dictionary,correct_name_data(corrections_name,food_lines)) + ['\n'] + \
        ["✈️旅游频道,#genre#"] + sort_data(travel_dictionary,correct_name_data(corrections_name,travel_lines)) + ['\n'] + \
        ["🏥健康频道,#genre#"] + sort_data(health_dictionary,correct_name_data(corrections_name,health_lines)) + ['\n'] + \
        ["💰财经频道,#genre#"] + sort_data(finance_dictionary,correct_name_data(corrections_name,finance_lines)) + ['\n'] + \
        ["🛍️购物频道,#genre#"] + sort_data(shopping_dictionary,correct_name_data(corrections_name,shopping_lines)) + ['\n'] + \
        ["🎮游戏频道,#genre#"] + sort_data(game_dictionary,correct_name_data(corrections_name,game_lines)) + ['\n'] + \
        ["📰新闻频道,#genre#"] + sort_data(news_dictionary,correct_name_data(corrections_name,news_lines)) + ['\n'] + \
        ["🇨🇳中国综合,#genre#"] + sort_data(china_dictionary,correct_name_data(corrections_name,china_lines)) + ['\n'] + \
        ["🌐国际频道,#genre#"] + sort_data(international_dictionary,correct_name_data(corrections_name,international_lines)) + ['\n'] + \
        ["⚽体育频道,#genre#"] + sort_data(sports_dictionary,correct_name_data(corrections_name,sports_lines)) + ['\n'] + \
        ["🏆体育赛事,#genre#"] + normalized_tyss_lines + ['\n'] + \
        ["🏈咪咕赛事,#genre#"] + sorted(set(mgss_lines)) + ['\n'] + \
        ["🎭戏曲频道,#genre#"] + sort_data(traditional_opera_dictionary,correct_name_data(corrections_name,traditional_opera_lines)) + ['\n'] + \
        ["🧨春晚频道,#genre#"] + sort_data(spring_festival_gala_dictionary,correct_name_data(corrections_name,spring_festival_gala_lines)) + ['\n'] + \
        ["🏞️景区直播,#genre#"] + sort_data(camera_dictionary,correct_name_data(corrections_name,camera_lines)) + ['\n'] + \
        ["⭐收藏频道,#genre#"] + sort_data(favorite_dictionary,correct_name_data(corrections_name,favorite_lines)) + ['\n'] + \
        ["📦其他频道,#genre#"] + sorted(set(other_lines)) + ['\n'] + \
        ["🕒更新时间,#genre#"] + [version] + [about] + [MTV1] + [MTV2] + [MTV3] + [MTV4] + [MTV5] + ['\n']

# 精简版播放列表（只包含核心频道）
all_lines_lite = ["🌐央视频道,#genre#"] + sort_data(yangshi_dictionary,correct_name_data(corrections_name,yangshi_lines)) + ['\n'] + \
        ["📡卫视频道,#genre#"] + sort_data(weishi_dictionary,correct_name_data(corrections_name,weishi_lines)) + ['\n'] + \
        ["🏠地·方·台,#genre#"] + \
        sort_data(beijing_dictionary, correct_name_data(corrections_name, beijing_lines)) + \
        sort_data(shanghai_dictionary, correct_name_data(corrections_name, shanghai_lines)) + \
        sort_data(tianjin_dictionary, correct_name_data(corrections_name, tianjin_lines)) + \
        sort_data(chongqing_dictionary, correct_name_data(corrections_name, chongqing_lines)) + \
        sort_data(guangdong_dictionary, correct_name_data(corrections_name, guangdong_lines)) + \
        sort_data(jiangsu_dictionary, correct_name_data(corrections_name, jiangsu_lines)) + \
        sort_data(zhejiang_dictionary, correct_name_data(corrections_name, zhejiang_lines)) + \
        sort_data(shandong_dictionary, correct_name_data(corrections_name, shandong_lines)) + \
        sort_data(henan_dictionary, correct_name_data(corrections_name, henan_lines)) + \
        sort_data(sichuan_dictionary, correct_name_data(corrections_name, sichuan_lines)) + \
        sort_data(hebei_dictionary, correct_name_data(corrections_name, hebei_lines)) + \
        sort_data(hunan_dictionary, correct_name_data(corrections_name, hunan_lines)) + \
        sort_data(hubei_dictionary, correct_name_data(corrections_name, hubei_lines)) + \
        sort_data(anhui_dictionary, correct_name_data(corrections_name, anhui_lines)) + \
        sort_data(fujian_dictionary, correct_name_data(corrections_name, fujian_lines)) + \
        sort_data(shaanxi_dictionary, correct_name_data(corrections_name, shaanxi_lines)) + \
        sort_data(liaoning_dictionary, correct_name_data(corrections_name, liaoning_lines)) + \
        sort_data(jiangxi_dictionary, correct_name_data(corrections_name, jiangxi_lines)) + \
        sort_data(heilongjiang_dictionary, correct_name_data(corrections_name, heilongjiang_lines)) + \
        sort_data(jilin_dictionary, correct_name_data(corrections_name, jilin_lines)) + \
        sort_data(shanxi_dictionary, correct_name_data(corrections_name, shanxi_lines)) + \
        sort_data(guangxi_dictionary, correct_name_data(corrections_name, guangxi_lines)) + \
        sort_data(yunnan_dictionary, correct_name_data(corrections_name, yunnan_lines)) + \
        sort_data(guizhou_dictionary, correct_name_data(corrections_name, guizhou_lines)) + \
        sort_data(gansu_dictionary, correct_name_data(corrections_name, gansu_lines)) + \
        sort_data(neimenggu_dictionary, correct_name_data(corrections_name, neimenggu_lines)) + \
        sort_data(xinjiang_dictionary, correct_name_data(corrections_name, xinjiang_lines)) + \
        sort_data(hainan_dictionary, correct_name_data(corrections_name, hainan_lines)) + \
        sort_data(ningxia_dictionary, correct_name_data(corrections_name, ningxia_lines)) + \
        sort_data(qinghai_dictionary, correct_name_data(corrections_name, qinghai_lines)) + \
        sort_data(xizang_dictionary, correct_name_data(corrections_name, xizang_lines)) + ['\n'] + \
        ["🕒更新时间,#genre#"] + [version] + [about] + [MTV1] + [MTV2] + [MTV3] + [MTV4] + [MTV5] + ['\n']

# 定制版播放列表
all_lines_custom = [
        "🌐央视频道,#genre#"] + sort_data(yangshi_dictionary, correct_name_data(corrections_name, yangshi_lines)) + ['\n'] + \
        ["📡卫视频道,#genre#"] + sort_data(weishi_dictionary, correct_name_data(corrections_name, weishi_lines)) + ['\n'] + \
        ["🕒更新时间,#genre#"] + [version] + [about] + [MTV1] + [MTV2] + [MTV3] + [MTV4] + [MTV5] + ['\n']

# 文件路径定义
output_full = "output/full.txt"
output_lite = "output/lite.txt"
output_custom = "output/custom.txt"
output_others = "output/others.txt"

try:
    # 写入完整版
    with open(output_full, 'w', encoding='utf-8') as f:
        for line in all_lines_full:
            f.write(line + '\n')
    print(f"合并后的文本已保存到文件: {output_full}")

    # 写入精简版
    with open(output_lite, 'w', encoding='utf-8') as f:
        for line in all_lines_lite:
            f.write(line + '\n')
    print(f"合并后的文本已保存到文件: {output_lite}")

    # 写入定制版
    with open(output_custom, 'w', encoding='utf-8') as f:
        for line in all_lines_custom:
            f.write(line + '\n')
    print(f"合并后的文本已保存到文件: {output_custom}")

    # 写入未分类源
    with open(output_others, 'w', encoding='utf-8') as f:
        for line in other_lines:
            f.write(line + '\n')
    print(f"Others已保存到文件: {output_others}")

except Exception as e:
    print(f"保存文件时发生错误：{e}")

# ========= 生成M3U格式文件 =========

print(f"time: {datetime.now().strftime('%Y%m%d_%H_%M_%S')}")

# 读取频道Logo库
channels_logos = read_txt_to_array('assets/livesource/logo.txt')

def get_logo_by_channel_name(channel_name):
    """根据频道名称获取Logo URL"""
    for line in channels_logos:
        if not line.strip():
            continue
        name, url = line.split(',')
        if name == channel_name:
            return url
    return None

def make_m3u(txt_file, m3u_file):
    """将TXT格式转换为M3U格式"""
    try:
        output_text = '#EXTM3U x-tvg-url="https://live.fanmingming.cn/e.xml"\n'

        with open(txt_file, "r", encoding='utf-8') as file:
            input_text = file.read()

        lines = input_text.strip().split("\n")
        group_name = ""
        
        for line in lines:
            parts = line.split(",")
            if len(parts) == 2 and "#genre#" in line:
                group_name = parts[0]
            elif len(parts) == 2:
                channel_name = parts[0]
                channel_url = parts[1]
                logo_url = get_logo_by_channel_name(channel_name)
                
                if logo_url is None:
                    output_text += f"#EXTINF:-1 group-title=\"{group_name}\",{channel_name}\n"
                    output_text += f"{channel_url}\n"
                else:
                    output_text += f"#EXTINF:-1 tvg-name=\"{channel_name}\" tvg-logo=\"{logo_url}\" group-title=\"{group_name}\",{channel_name}\n"
                    output_text += f"{channel_url}\n"

        with open(f"{m3u_file}", "w", encoding='utf-8') as file:
            file.write(output_text)

        print(f"M3U文件 '{m3u_file}' 生成成功。")
        
    except Exception as e:
        print(f"发生错误: {e}")

# 为各个版本生成对应的M3U文件
make_m3u(output_full, output_full.replace(".txt", ".m3u"))
make_m3u(output_lite, output_lite.replace(".txt", ".m3u"))
make_m3u(output_custom, output_custom.replace(".txt", ".m3u"))

# ========= 统计信息和性能监控 =========

# 计算执行时间
timeend = datetime.now()
elapsed_time = timeend - timestart
total_seconds = elapsed_time.total_seconds()

# 转换为分钟和秒
minutes = int(total_seconds // 60)
seconds = int(total_seconds % 60)

# 格式化开始和结束时间
timestart_str = timestart.strftime("%Y%m%d_%H_%M_%S")
timeend_str = timeend.strftime("%Y%m%d_%H_%M_%S")

print(f"开始时间: {timestart_str}")
print(f"结束时间: {timeend_str}")
print(f"执行时间: {minutes} 分 {seconds} 秒")

# 统计各类数据行数
all_lines_full_count = len(all_lines_full)
blacklist_count = len(blacklist_set)
other_lines_count = len(other_lines)

print(f"黑名单行数: {blacklist_count}")
print(f"完整版行数: {all_lines_full_count}")
print(f"其他源行数: {other_lines_count}")
print(f"处理的唯一URL数: {len(processed_urls)}")

# ========= 脚本结束 =========
```

主要优化点（保持您原有的代码风格）：

1. 黑名单优化

· 使用集合存储黑名单，提高查找速度
· 提前在黑名单检查时就过滤，避免后续处理
· 统一黑名单加载函数

2. 频道分发优化

· 构建category_mapping字典，实现O(1)的频道分类查找
· 使用get_channel_category()函数统一处理分类逻辑
· 减少if-elif链的长度，提高效率

3. URL去重优化

· 使用processed_urls集合全局去重
· 避免重复处理和重复检查

4. 保持原有风格

· 保留所有原有的变量名
· 保持相同的注释风格
· 维持原有的代码结构
· 使用相同的函数名和逻辑流程

5. 性能提升

· 黑名单检查从O(n)提升到O(1)
· 频道分类查找从O(n)提升到O(1)
· URL去重从O(n)提升到O(1)

这样既保持了您熟悉的代码风格，又应用了优化后的逻辑，处理大量数据时会更加高效。