#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# ====== 直播源聚合处理工具 v2.06 ======
# ======= LiveSource-Collector =======
# ============ 优化维护版 ============

import urllib.request
import re
import os
import time
import socket
import random
from datetime import datetime, timedelta, timezone
from urllib.parse import urlparse
import opencc

# ========= 配置常量 =========
CONFIG = {
    "paths": {
        "output": "output",
        "assets": {
            "livesource": "assets/livesource",
            "blacklist": "assets/livesource/blacklist",
            "channels": "assets/livesource/主频道",
            "locals": "assets/livesource/地方台",
            "manual": "assets/livesource/手工区"
        },
        "files": {
            "urls_daily": "assets/livesource/urls-daily.txt",
            "corrections": "assets/livesource/corrections_name.txt",
            "logos": "assets/livesource/logo.txt",
            "today_recommend": "assets/livesource/手工区/今日推荐.txt",
            "today_channel": "assets/livesource/手工区/今日推台.txt",
            "about": "assets/livesource/手工区/about.txt"
        }
    },
    "http": {
        "timeout": 8,
        "retries": 2,
        "backoff_factor": 1.0,
        "whitelist_threshold": 2000
    },
    "categories": {
        "main_channels": [
            "央视", "卫视", "体育", "体育赛事", "咪咕赛事", "数字", "电影", "电视剧",
            "纪录片", "动画片", "收音机", "综艺", "虎牙", "斗鱼", "解说", "音乐",
            "美食", "旅游", "健康", "财经", "购物", "游戏", "新闻", "中国", "国际",
            "戏曲", "春晚", "直播中国", "收藏频道"
        ],
        "local_channels": [
            "北京", "上海", "广东", "江苏", "浙江", "山东", "四川", "河南", "湖南",
            "重庆", "天津", "湖北", "安徽", "福建", "辽宁", "陕西", "河北", "江西",
            "广西", "云南", "山西", "黑龙江", "吉林", "贵州", "甘肃", "内蒙古",
            "新疆", "海南", "宁夏", "青海", "西藏", "香港", "澳门", "闽南"
        ],
        "manual_channels": ["浙江", "广东", "湖北", "上海", "江苏"]
    },
    "processing": {
        "removal_keywords": [
            "_电信", "电信", "频道", "频陆", "备陆", "壹陆", "贰陆", "叁陆", "肆陆",
            "伍陆", "陆陆", "柒陆", "肆柒", "频英", "频特", "频国", "频晴", "频粤",
            "高清", "超清", "标清", "斯特", "粤陆", "国陆", "频壹", "频贰", "肆贰",
            "频测", "咪咕", "闽特", "高特", "频高", "频标", "汝阳", "频效", "国标",
            "粤标", "频推", "频流", "粤高", "频限", "实时", "美推", "频美", "英陆",
            "(北美)", "「回看」", "[超清]", "「IPV4」", "「IPV6」", "_ITV", "(HK)",
            "AKtv", "HD", "[HD]", "(HD)", "（HD）", "{HD}", "<HD>", "-HD", "[BD]",
            "SD", "[SD]", "(SD)", "{SD}", "<SD>", "[VGA]", "4Gtv", "1080", "720",
            "480", "VGA", "4K", "(4K)", "{4K}", "<4K>", "(VGA)", "{VGA}", "<VGA>",
            "「4gTV」", "「LiTV」"
        ],
        "sports_exclude_txt": ["玉玉软件", "榴芒电视", "公众号", "麻豆", "「回看」"],
        "sports_exclude_html": ["玉玉软件", "榴芒电视", "公众号", "咪视通", "麻豆", "「回看」"]
    },
    "network": {
        "user_agents": [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.82 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36"
        ],
        "aktv_url": "https://raw.githubusercontent.com/xiaoran67/update/refs/heads/main/assets/livesource/blacklist/whitelist_manual.txt"
    },
    "display": {
        "local_emojis": {
            "北京": "🏛️", "上海": "🏙️", "广东": "🐯", "江苏": "🎐", "浙江": "🧵",
            "山东": "⛰️", "四川": "🐼", "河南": "🐘", "河北": "⛩️", "湖南": "🌶️",
            "重庆": "🏞️", "天津": "🚢", "湖北": "🏯", "安徽": "🌾", "福建": "🌊",
            "辽宁": "⛰️", "陕西": "🔥", "江西": "🔥", "广西": "💃", "云南": "☁️",
            "山西": "🏮", "黑龙江": "🐻", "吉林": "🎎", "贵州": "⛰️", "甘肃": "🐫",
            "内蒙古": "🐮", "新疆": "🍇", "海南": "🏝️", "宁夏": "🕌", "青海": "🐑",
            "西藏": "🐐", "香港": "🇭🇰", "澳门": "🇲🇴", "闽南": "🇨🇳"
        },
        "channel_emojis": {
            "央视": "🌐", "卫视": "📡", "体育赛事": "🏆️", "咪咕赛事": "🏈",
            "数字": "🔢", "电影": "🎬", "电视剧": "📺", "动画片": "🐱",
            "纪录片": "🎥", "收音机": "📻", "综艺": "🎭", "虎牙": "🐯",
            "斗鱼": "🐠", "解说": "🎤", "音乐": "🎵", "美食": "🍜",
            "旅游": "✈️", "健康": "🏥", "财经": "💰", "购物": "🛍️",
            "游戏": "🎮", "新闻": "📰", "中国": "🇨🇳", "国际": "🌐",
            "体育": "🏀", "戏曲": "🎭", "春晚": "🧨", "直播中国": "🏞️",
            "收藏频道": "⭐", "其他": "📦", "更新时间": "🕒"
        }
    }
}

# ========= 工具函数 =========
def get_beijing_time() -> datetime:
    """获取北京时间"""
    return datetime.now(timezone.utc) + timedelta(hours=8)

def read_txt_to_array(file_path: str) -> list:
    """读取文本文件内容到数组"""
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            return [line.strip() for line in file if line.strip()]
    except FileNotFoundError:
        print(f"❌ 文件未找到: {file_path}")
        return []
    except Exception as e:
        print(f"❌ 读取文件错误 {file_path}: {e}")
        return []

def read_blacklist(file_path: str) -> list:
    """从黑名单文件读取URL列表"""
    blacklist = []
    for line in read_txt_to_array(file_path):
        if ',' in line:
            blacklist.append(line.split(',')[1].strip())
    return blacklist

def get_random_user_agent() -> str:
    """获取随机User-Agent"""
    return random.choice(CONFIG["network"]["user_agents"])

def get_http_response(url: str, timeout: int = 8, retries: int = 2, backoff_factor: float = 1.0) -> str:
    """获取HTTP响应（带重试机制）"""
    headers = {'User-Agent': get_random_user_agent()}
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=timeout) as response:
                return response.read().decode('utf-8')
        except urllib.error.HTTPError as e:
            print(f"[HTTPError] Code: {e.code}, URL: {url}")
            break
        except urllib.error.URLError as e:
            print(f"[URLError] Reason: {e.reason}, Attempt: {attempt + 1}")
        except socket.timeout:
            print(f"[Timeout] URL: {url}, Attempt: {attempt + 1}")
        except Exception as e:
            print(f"[Exception] {type(e).__name__}: {e}, Attempt: {attempt + 1}")
            if attempt < retries - 1:
                time.sleep(backoff_factor * (2 ** attempt))
    return None

def clean_url(url: str) -> str:
    """清理URL（移除$后的参数）"""
    last_dollar_index = url.rfind('$')
    return url[:last_dollar_index] if last_dollar_index != -1 else url

def clean_channel_name(channel_name: str) -> str:
    """清理频道名称"""
    for keyword in CONFIG["processing"]["removal_keywords"]:
        channel_name = channel_name.replace(keyword, "")
    
    if channel_name.endswith("HD"):
        channel_name = channel_name[:-2]
    
    if channel_name.endswith("台") and len(channel_name) > 3:
        channel_name = channel_name[:-1]
    
    # 繁体转简体
    converter = opencc.OpenCC('t2s')
    return converter.convert(channel_name)

def process_channel_name(name_part: str) -> str:
    """处理频道名称部分（CCTV和卫视特殊处理）"""
    if "CCTV" in name_part and "://" not in name_part:
        # 处理CCTV频道名称
        name_part = name_part.replace("IPV6", "").replace("PLUS", "+").replace("1080", "")
        filtered_str = ''.join(char for char in name_part if char.isdigit() or char in 'K+')
        
        if not filtered_str.strip():
            filtered_str = name_part.replace("CCTV", "")
        
        if len(filtered_str) > 2 and re.search(r'4K|8K', filtered_str):
            filtered_str = re.sub(r'(4K|8K).*', r'\1', filtered_str)
            if len(filtered_str) > 2:
                filtered_str = re.sub(r'(4K|8K)', r'(\1)', filtered_str)
        
        return "CCTV" + filtered_str
    elif "卫视" in name_part:
        # 处理卫视频道名称
        return re.sub(r'卫视「.*」', '卫视', name_part)
    
    return name_part

def get_url_file_extension(url: str) -> str:
    """获取URL文件扩展名"""
    parsed_url = urlparse(url)
    return os.path.splitext(parsed_url.path)[1]

def convert_m3u_to_txt(m3u_content: str) -> str:
    """将M3U格式转换为TXT格式"""
    lines = m3u_content.split('\n')
    txt_lines = []
    channel_name = ""
    
    for line in lines:
        if line.startswith("#EXTM3U"):
            continue
        elif line.startswith("#EXTINF"):
            channel_name = line.split(',')[-1].strip()
        elif line.startswith("http") or line.startswith("rtmp") or line.startswith("p3p"):
            txt_lines.append(f"{channel_name},{line.strip()}")
        elif "#genre#" not in line and "," in line and "://" in line:
            if re.match(r'^[^,]+,[^\s]+://[^\s]+$', line):
                txt_lines.append(line)
    
    return '\n'.join(txt_lines)

def load_corrections_name(file_path: str) -> dict:
    """加载频道名称修正字典"""
    corrections = {}
    try:
        for line in read_txt_to_array(file_path):
            if line.startswith('#'):
                continue
            parts = line.strip().split(',')
            if len(parts) >= 2:
                correct_name = parts[0]
                for name in parts[1:]:
                    if name:
                        corrections[name] = correct_name
    except Exception as e:
        print(f"❌ 加载修正字典错误: {e}")
    
    return corrections

def correct_name_data(corrections: dict, data: list) -> list:
    """修正频道名称数据"""
    corrected = []
    for line in data:
        if ',' not in line:
            continue
        name, url = line.split(',', 1)
        if name in corrections and name != corrections[name]:
            name = corrections[name]
        corrected.append(f"{name},{url}")
    return corrected

def sort_data(order: list, data: list) -> list:
    """按指定顺序排序数据"""
    order_dict = {name: i for i, name in enumerate(order)}
    
    def sort_key(line):
        if ',' not in line:
            return len(order)
        name = line.split(',')[0]
        return order_dict.get(name, len(order))
    
    return sorted(data, key=sort_key)

def normalize_date_to_md(text: str) -> str:
    """将日期格式规范化为MM-DD格式"""
    text = text.strip()
    
    def format_md(match):
        month = int(match.group(1))
        day = int(match.group(2))
        after = match.group(3) or ''
        if not after.startswith(' '):
            after = ' ' + after
        return f"{month:02d}-{day:02d}{after}"
    
    # 匹配多种日期格式
    patterns = [
        r'^0?(\d{1,2})/0?(\d{1,2})(.*)',      # 01/02格式
        r'^\d{4}-0?(\d{1,2})-0?(\d{1,2})(.*)', # 2024-01-02格式
        r'^0?(\d{1,2})月0?(\d{1,2})日(.*)'     # 1月2日格式
    ]
    
    for pattern in patterns:
        if re.match(pattern, text):
            return re.sub(pattern, format_md, text)
    
    return text

def filter_lines(lines: list, exclude_keywords: list) -> list:
    """过滤包含特定关键词的行"""
    return [line for line in lines if not any(keyword in line for keyword in exclude_keywords)]

def custom_tyss_sort(lines: list) -> list:
    """自定义体育赛事排序（数字前缀的倒序，其他正序）"""
    digit_prefix = []
    others = []
    
    for line in lines:
        if ',' not in line:
            continue
        name_part = line.split(',')[0].strip()
        if name_part and name_part[0].isdigit():
            digit_prefix.append(line)
        else:
            others.append(line)
    
    return sorted(digit_prefix, reverse=True) + sorted(others)

def get_random_url(file_path: str) -> str:
    """从文件中随机获取URL"""
    urls = []
    for line in read_txt_to_array(file_path):
        if ',' in line:
            urls.append(line.split(',')[-1])
    return random.choice(urls) if urls else None

# ========= 频道管理器类 =========
class ChannelManager:
    """频道管理器，负责频道的分类和存储"""
    
    def __init__(self):
        # 初始化所有频道存储列表
        self.channels = {
            # 主频道
            "yangshi": [],      # 央视
            "weishi": [],       # 卫视
            
            # 地方台
            "beijing": [], "shanghai": [], "guangdong": [], "jiangsu": [],
            "zhejiang": [], "shandong": [], "sichuan": [], "henan": [],
            "hunan": [], "chongqing": [], "tianjin": [], "hubei": [],
            "anhui": [], "fujian": [], "liaoning": [], "shaanxi": [],
            "hebei": [], "jiangxi": [], "guangxi": [], "yunnan": [],
            "shanxi": [], "heilongjiang": [], "jilin": [], "guizhou": [],
            "gansu": [], "neimenggu": [], "xinjiang": [], "hainan": [],
            "ningxia": [], "qinghai": [], "xizang": [],
            
            # 港澳台
            "hongkong": [], "macau": [], "minnan": [],
            
            # 其他频道
            "digital": [], "movie": [], "tv_drama": [], "documentary": [],
            "cartoon": [], "radio": [], "variety": [], "huya": [], "douyu": [],
            "commentary": [], "music": [], "food": [], "travel": [], "health": [],
            "finance": [], "shopping": [], "game": [], "news": [], "china": [],
            "international": [], "sports": [], "tyss": [], "mgss": [],
            "traditional_opera": [], "spring_festival_gala": [], "camera": [],
            "favorite": [], "other": [], "other_url": []
        }
        
        # 频道字典
        self.dictionaries = {}
        # 名称修正字典
        self.corrections = {}
        # 黑名单
        self.blacklist = set()
        # 已处理URL集合
        self.processed_urls = set()
        
        # 加载数据
        self.load_dictionaries()
        self.load_corrections()
        self.load_blacklist()
    
    def load_dictionaries(self):
        """加载频道字典"""
        print("📋 加载频道字典...")
        
        # 加载主频道字典
        for channel in CONFIG["categories"]["main_channels"]:
            file_path = f"{CONFIG['paths']['assets']['channels']}/{channel}.txt"
            self.dictionaries[channel] = read_txt_to_array(file_path)
        
        # 加载地方台字典
        for local in CONFIG["categories"]["local_channels"]:
            file_name = "内蒙.txt" if local == "内蒙古" else f"{local}.txt"
            file_path = f"{CONFIG['paths']['assets']['locals']}/{file_name}"
            self.dictionaries[local] = read_txt_to_array(file_path)
        
        # 打印统计信息
        print(f"✅ 字典加载完成:")
        print(f"   央视: {len(self.dictionaries.get('央视', []))} 条")
        print(f"   卫视: {len(self.dictionaries.get('卫视', []))} 条")
        print(f"   地方台: {len(CONFIG['categories']['local_channels'])}个分类已加载")
        print(f"   其他分类: {len(CONFIG['categories']['main_channels'])-2}个分类已加载")
    
    def load_corrections(self):
        """加载名称修正字典"""
        self.corrections = load_corrections_name(CONFIG["paths"]["files"]["corrections"])
        
        print("🔄 频道更名修正字典:")
        print(f"   加载了 {len(self.corrections)} 条修正规则")
        if self.corrections:
            print("   修正规则示例 (前3条):")
            for i, (wrong_name, correct_name) in enumerate(list(self.corrections.items())[:3]):
                print(f"     {i+1}. '{wrong_name}' → '{correct_name}'")
            if len(self.corrections) > 3:
                print(f"     ... 还有 {len(self.corrections) - 3} 条修正规则")
        else:
            print("   未加载到有效的修正规则")
        print()
    
    def load_blacklist(self):
        """加载黑名单"""
        blacklist_auto = read_blacklist(f"{CONFIG['paths']['assets']['blacklist']}/blacklist_auto.txt")
        blacklist_manual = read_blacklist(f"{CONFIG['paths']['assets']['blacklist']}/blacklist_manual.txt")
        self.blacklist = set(blacklist_auto + blacklist_manual)
        
        print("🔴 黑名单统计信息:")
        print(f"   自动维护: {len(blacklist_auto)} 条")
        print(f"   手动维护: {len(blacklist_manual)} 条")
        print(f"   合并去重: {len(self.blacklist)} 条")
        
        if self.blacklist:
            print("   黑名单示例 (前3条):")
            for i, url in enumerate(list(self.blacklist)[:3]):
                print(f"     {i+1}. {url}")
            if len(self.blacklist) > 3:
                print(f"     ... 还有 {len(self.blacklist) - 3} 条")
        print()
    
    def process_channel_line(self, line: str):
        """处理单行频道信息"""
        if "#genre#" in line or "#EXTINF:" in line or "," not in line or "://" in line:
            return
        
        channel_name, channel_address = line.split(',', 1)
        channel_name = channel_name.strip()
        channel_address = clean_url(channel_address.strip())
        
        # 黑名单检查
        if channel_address in self.blacklist:
            print(f"🚫 黑名单过滤: {channel_name}")
            return
        
        # URL去重检查
        if channel_address in self.processed_urls:
            print(f"🔄 URL去重: {channel_name}")
            return
        self.processed_urls.add(channel_address)
        
        # 清理和修正频道名称
        channel_name = clean_channel_name(channel_name)
        if channel_name in self.corrections:
            corrected_name = self.corrections[channel_name]
            if corrected_name != channel_name:
                print(f"🔧 名称纠错: {channel_name} -> {corrected_name}")
                channel_name = corrected_name
        
        # 重新组合行
        processed_name = process_channel_name(channel_name)
        processed_line = f"{processed_name},{channel_address}"
        
        # 频道分类
        self._categorize_channel(channel_name, processed_line, channel_address)
    
    def _categorize_channel(self, channel_name: str, processed_line: str, url: str):
        """频道分类逻辑"""
        categorized = False
        
        # 1. 央视频道
        if "CCTV" in channel_name:
            self.channels["yangshi"].append(processed_line)
            categorized = True
        
        # 2. 卫视频道
        elif channel_name in self.dictionaries.get("卫视", []):
            self.channels["weishi"].append(processed_line)
            categorized = True
        
        # 3. 体育频道
        elif channel_name in self.dictionaries.get("体育", []):
            self.channels["sports"].append(processed_line)
            categorized = True
        
        # 4. 体育赛事（关键词匹配）
        elif any(keyword in channel_name for keyword in self.dictionaries.get("体育赛事", [])):
            self.channels["tyss"].append(processed_line)
            categorized = True
        
        # 5. 咪咕赛事（关键词匹配）
        elif any(keyword in channel_name for keyword in self.dictionaries.get("咪咕赛事", [])):
            self.channels["mgss"].append(processed_line)
            categorized = True
        
        # 6. 地方台分类
        if not categorized:
            for local_key, local_name in [
                ("beijing", "北京"), ("shanghai", "上海"), ("guangdong", "广东"),
                ("jiangsu", "江苏"), ("zhejiang", "浙江"), ("shandong", "山东"),
                ("sichuan", "四川"), ("henan", "河南"), ("hunan", "湖南"),
                ("chongqing", "重庆"), ("tianjin", "天津"), ("hubei", "湖北"),
                ("anhui", "安徽"), ("fujian", "福建"), ("liaoning", "辽宁"),
                ("shaanxi", "陕西"), ("hebei", "河北"), ("jiangxi", "江西"),
                ("guangxi", "广西"), ("yunnan", "云南"), ("shanxi", "山西"),
                ("heilongjiang", "黑龙江"), ("jilin", "吉林"), ("guizhou", "贵州"),
                ("gansu", "甘肃"), ("neimenggu", "内蒙古"), ("xinjiang", "新疆"),
                ("hainan", "海南"), ("ningxia", "宁夏"), ("qinghai", "青海"),
                ("xizang", "西藏"), ("hongkong", "香港"), ("macau", "澳门"),
                ("minnan", "闽南")
            ]:
                if channel_name in self.dictionaries.get(local_name, []):
                    self.channels[local_key].append(processed_line)
                    categorized = True
                    break
        
        # 7. 其他主频道分类
        if not categorized:
            for channel_key, channel_name_dict in [
                ("digital", "数字"), ("movie", "电影"), ("tv_drama", "电视剧"),
                ("documentary", "纪录片"), ("cartoon", "动画片"), ("radio", "收音机"),
                ("variety", "综艺"), ("huya", "虎牙"), ("douyu", "斗鱼"),
                ("commentary", "解说"), ("music", "音乐"), ("food", "美食"),
                ("travel", "旅游"), ("health", "健康"), ("finance", "财经"),
                ("shopping", "购物"), ("game", "游戏"), ("news", "新闻"),
                ("china", "中国"), ("international", "国际"),
                ("traditional_opera", "戏曲"), ("spring_festival_gala", "春晚"),
                ("camera", "直播中国"), ("favorite", "收藏频道")
            ]:
                if channel_name in self.dictionaries.get(channel_name_dict, []):
                    self.channels[channel_key].append(processed_line)
                    categorized = True
                    break
        
        # 8. 未分类频道
        if not categorized:
            if url not in self.channels["other_url"]:
                self.channels["other_url"].append(url)
                self.channels["other"].append(f"{channel_name},{url}")
    
    def process_url(self, url: str):
        """处理单个URL源"""
        try:
            self.channels["other"].append(f"◆◆◆　{url}")
            
            response = get_http_response(url)
            if not response:
                return
            
            text = response.strip()
            is_m3u = text.startswith("#EXTM3U") or text.startswith("#EXTINF")
            
            if get_url_file_extension(url) in [".m3u", ".m3u8"] or is_m3u:
                text = convert_m3u_to_txt(text)
            
            lines = text.split('\n')
            print(f"行数: {len(lines)}")
            
            for line in lines:
                if ("#genre#" not in line and "," in line and "://" in line and 
                    "tvbus://" not in line and "/udp/" not in line):
                    
                    if ',' not in line:
                        continue
                    
                    name, addr = line.split(',', 1)
                    
                    if "#" not in addr:
                        self.process_channel_line(line)
                    else:
                        url_list = addr.split('#')
                        for channel_url in url_list:
                            self.process_channel_line(f"{name},{channel_url}")
            
            self.channels["other"].append('\n')
            
        except Exception as e:
            print(f"❌ 处理URL时发生错误：{e}")
    
    def process_whitelist(self):
        """处理白名单"""
        print("🟢 处理白名单自动文件...")
        whitelist_lines = read_txt_to_array(f"{CONFIG['paths']['assets']['blacklist']}/whitelist_auto.txt")
        
        print(f"   读取到 {len(whitelist_lines)} 条记录")
        print(f"   跳过标题行和表头...")
        
        valid_count = 0
        valid_samples = []
        
        for i, line in enumerate(whitelist_lines):
            if i < 2 or line.startswith("RespoTime,whitelist,#genre#"):
                continue
            
            if "#genre#" not in line and "," in line and "://" in line:
                parts = line.split(",")
                if len(parts) >= 3:
                    valid_count += 1
                    
                    if len(valid_samples) < 3:
                        valid_samples.append(line)
                    
                    try:
                        response_time = float(parts[0].replace("ms", ""))
                    except ValueError:
                        print(f"response_time转换失败: {line}")
                        response_time = 60000
                    
                    if response_time < CONFIG["http"]["whitelist_threshold"]:
                        self.process_channel_line(",".join(parts[1:]))
        
        print(f"   有效白名单记录: {valid_count} 条")
        if valid_samples:
            print("   白名单示例 (前3条):")
            for i, line in enumerate(valid_samples[:3]):
                display_line = line[:80] + "..." if len(line) > 80 else line
                print(f"     {i+1}. {display_line}")
            if valid_count > 3:
                print(f"     ... 还有 {valid_count - 3} 条")
        print()
    
    def process_aktv(self):
        """处理AKTV源"""
        aktv_text = get_http_response(CONFIG["network"]["aktv_url"])
        
        if aktv_text:
            print("AKTV成功获取内容")
            aktv_text = convert_m3u_to_txt(aktv_text)
            aktv_lines = aktv_text.strip().split('\n')
        else:
            print("AKTV请求失败，从本地获取！")
            aktv_lines = read_txt_to_array(f"{CONFIG['paths']['assets']['manual']}/AKTV.txt")
        
        print("📺 AKTV频道统计:")
        print(f"   获取到 {len(aktv_lines)} 条AKTV频道记录")
        if aktv_lines:
            print("   AKTV频道示例 (前3条):")
            for i, line in enumerate(aktv_lines[:3]):
                display_line = line[:60] + "..." if len(line) > 60 else line
                print(f"     {i+1}. {display_line}")
            if len(aktv_lines) > 3:
                print(f"     ... 还有 {len(aktv_lines) - 3} 条")
        print()
        
        print(f"处理AKTV数据，共 {len(aktv_lines)} 行")
        for line in aktv_lines:
            self.process_channel_line(line)
    
    def process_manual_sources(self):
        """处理手工区源"""
        print("🔧 处理手工区高质量源...")
        
        manual_files = {
            "zhejiang": "浙江频道.txt",
            "guangdong": "广东频道.txt",
            "hubei": "湖北频道.txt",
            "shanghai": "上海频道.txt",
            "jiangsu": "江苏频道.txt"
        }
        
        total_count = 0
        for channel_key, filename in manual_files.items():
            lines = read_txt_to_array(f"{CONFIG['paths']['assets']['manual']}/{filename}")
            self.channels[channel_key].extend(lines)
            count = len(lines)
            total_count += count
            print(f"   {filename[:-4]}: {count} 条")
        
        print(f"   手工区总计: {total_count} 条")
        print()

# ========= 播放列表生成器类 =========
class PlaylistGenerator:
    """播放列表生成器，负责生成各种格式的播放列表"""
    
    def __init__(self, channel_manager: ChannelManager):
        self.channel_manager = channel_manager
    
    def generate_sports_html(self, data_list: list, output_file: str = 'output/tiyu.html'):
        """生成体育赛事HTML页面"""
        html_head = '''
    <!DOCTYPE html>
    <html lang="zh">
    <head>
        <meta charset="UTF-8">        
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-6061710286208572"
     crossorigin="anonymous"></script>
        <!-- Setup Google Analytics -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=G-BS1Z4F5BDN"></script>
        <script> 
        window.dataLayer = window.dataLayer || []; 
        function gtag(){dataLayer.push(arguments);} 
        gtag('js', new Date()); 
        gtag('config', 'G-BS1Z4F5BDN'); 
        </script>
        <title>最新体育赛事</title>
        <style>
            body { font-family: sans-serif; padding: 20px; background: #f9f9f9; }
            .item { margin-bottom: 20px; padding: 12px; background: #fff; border-radius: 8px;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.06); }
            .title { font-weight: bold; font-size: 1.1em; color: #333; margin-bottom: 5px; }
            .url-wrapper { display: flex; align-items: center; gap: 10px; }
            .url {
                max-width: 80%;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                font-size: 0.9em;
                color: #555;
                background: #f0f0f0;
                padding: 6px;
                border-radius: 4px;
                flex-grow: 1;
            }
            .copy-btn {
                background-color: #007BFF;
                border: none;
                color: white;
                padding: 6px 10px;
                border-radius: 4px;
                cursor: pointer;
                font-size: 0.8em;
            }
            .copy-btn:hover {
                background-color: #0056b3;
            }
        </style>
    </head>
    <body>
    <h2>📋 最新体育赛事列表</h2>
    '''
        
        html_body = ''
        for idx, entry in enumerate(data_list):
            if ',' not in entry:
                continue
            info, url = entry.split(',', 1)
            url_id = f"url_{idx}"
            html_body += f'''
        <div class="item">
            <div class="title">🕒 {info}</div>
            <div class="url-wrapper">
                <div class="url" id="{url_id}">{url}</div>
                <button class="copy-btn" onclick="copyToClipboard('{url_id}')">复制</button>
            </div>
        </div>
        '''
        
        html_tail = '''
    <script>
        function copyToClipboard(id) {
            const el = document.getElementById(id);
            const text = el.textContent;
            navigator.clipboard.writeText(text).then(() => {
                alert("已复制链接！");
            }).catch(err => {
                alert("复制失败: " + err);
            });
        }
    </script>
    </body>
    </html>
    '''
        
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(html_head + html_body + html_tail)
        print(f"✅ 网页已生成：{output_file}")
    
    def make_m3u(self, txt_file: str, m3u_file: str):
        """将TXT文件转换为M3U格式"""
        try:
            output_text = '#EXTM3U x-tvg-url="https://live.fanmingming.cn/e.xml"\n'
            
            # 读取频道Logo信息
            channels_logos = read_txt_to_array(CONFIG["paths"]["files"]["logos"])
            logo_dict = {}
            for line in channels_logos:
                if line.strip() and ',' in line:
                    name, url = line.split(',', 1)
                    logo_dict[name.strip()] = url.strip()
            
            with open(txt_file, "r", encoding='utf-8') as file:
                input_text = file.read()
            
            lines = input_text.strip().split("\n")
            group_name = ""
            
            for line in lines:
                parts = line.split(",")
                if len(parts) == 2 and "#genre#" in line:
                    group_name = parts[0]
                elif len(parts) == 2:
                    channel_name = parts[0]
                    channel_url = parts[1]
                    logo_url = logo_dict.get(channel_name)
                    
                    if logo_url is None:
                        output_text += f'#EXTINF:-1 group-title="{group_name}",{channel_name}\n'
                    else:
                        output_text += f'#EXTINF:-1 tvg-name="{channel_name}" tvg-logo="{logo_url}" group-title="{group_name}",{channel_name}\n'
                    
                    output_text += f"{channel_url}\n"
            
            with open(m3u_file, "w", encoding='utf-8') as file:
                file.write(output_text)
            
            print(f"▶️ M3U文件 '{m3u_file}' 生成成功。")
        except Exception as e:
            print(f"发生错误: {e}")
    
    def build_full_playlist(self) -> list:
        """构建完整版播放列表"""
        playlist = []
        
        # 央视频道
        playlist.append("🌐央视频道,#genre#")
        playlist.extend(sort_data(
            self.channel_manager.dictionaries.get("央视", []),
            correct_name_data(self.channel_manager.corrections, self.channel_manager.channels["yangshi"])
        ))
        playlist.append('\n')
        
        # 卫视频道
        playlist.append("📡卫视频道,#genre#")
        playlist.extend(sort_data(
            self.channel_manager.dictionaries.get("卫视", []),
            correct_name_data(self.channel_manager.corrections, self.channel_manager.channels["weishi"])
        ))
        playlist.append('\n')
        
        # 地方台频道（按指定顺序）
        local_order = [
            ("北京", "beijing"), ("上海", "shanghai"), ("广东", "guangdong"),
            ("江苏", "jiangsu"), ("浙江", "zhejiang"), ("山东", "shandong"),
            ("四川", "sichuan"), ("河南", "henan"), ("河北", "hebei"),
            ("湖南", "hunan"), ("重庆", "chongqing"), ("天津", "tianjin"),
            ("湖北", "hubei"), ("安徽", "anhui"), ("福建", "fujian"),
            ("辽宁", "liaoning"), ("陕西", "shaanxi"), ("河北", "hebei"),
            ("江西", "jiangxi"), ("广西", "guangxi"), ("云南", "yunnan"),
            ("山西", "shanxi"), ("黑龙江", "heilongjiang"), ("吉林", "jilin"),
            ("贵州", "guizhou"), ("甘肃", "gansu"), ("内蒙古", "neimenggu"),
            ("新疆", "xinjiang"), ("海南", "hainan"), ("宁夏", "ningxia"),
            ("青海", "qinghai"), ("西藏", "xizang")
        ]
        
        for display_name, channel_key in local_order:
            emoji = CONFIG["display"]["local_emojis"].get(display_name, "🏛️")
            playlist.append(f"{emoji}{display_name}频道,#genre#")
            
            if display_name in ["河南", "河北", "广西"]:
                playlist.extend(sorted(set(correct_name_data(
                    self.channel_manager.corrections, 
                    self.channel_manager.channels[channel_key]
                ))))
            else:
                playlist.extend(sort_data(
                    self.channel_manager.dictionaries.get(display_name, []),
                    correct_name_data(self.channel_manager.corrections, self.channel_manager.channels[channel_key])
                ))
            playlist.append('\n')
        
        # 专享频道
        playlist.append("☕️专享央视,#genre#")
        playlist.extend(read_txt_to_array(f"{CONFIG['paths']['assets']['manual']}/优质央视.txt"))
        playlist.append('\n')
        
        playlist.append("🍹专享卫视,#genre#")
        playlist.extend(read_txt_to_array(f"{CONFIG['paths']['assets']['manual']}/优质卫视.txt"))
        playlist.append('\n')
        
        playlist.append("⚽️SPORTS,#genre#")
        playlist.extend(read_txt_to_array(f"{CONFIG['paths']['assets']['manual']}/sports.txt"))
        playlist.append('\n')
        
        # 体育赛事
        if self.channel_manager.channels["tyss"]:
            playlist.append("🏆️体育赛事,#genre#")
            playlist.extend(self.channel_manager.channels["tyss"])
            playlist.append('\n')
        
        # 咪咕赛事
        if self.channel_manager.channels["mgss"]:
            playlist.append("🏈咪咕赛事,#genre#")
            playlist.extend(self.channel_manager.channels["mgss"])
            playlist.append('\n')
        
        # 港澳台频道
        for display_name, channel_key, emoji in [
            ("香港", "hongkong", "🇭🇰"), ("澳门", "macau", "🇲🇴"), ("闽南", "minnan", "🇨🇳")
        ]:
            playlist.append(f"{emoji}{display_name}频道,#genre#")
            playlist.extend(sort_data(
                self.channel_manager.dictionaries.get(display_name, []),
                correct_name_data(self.channel_manager.corrections, self.channel_manager.channels[channel_key])
            ))
            playlist.append('\n')
        
        # 其他主频道
        channel_mappings = [
            ("数字", "digital", "🔢"), ("电影", "movie", "🎬"), ("电视剧", "tv_drama", "📺"),
            ("动画片", "cartoon", "🐱"), ("纪录片", "documentary", "🎥"), ("收音机", "radio", "📻"),
            ("综艺", "variety", "🎭"), ("虎牙", "huya", "🐯"), ("斗鱼", "douyu", "🐠"),
            ("解说", "commentary", "🎤"), ("音乐", "music", "🎵"), ("美食", "food", "🍜"),
            ("旅游", "travel", "✈️"), ("健康", "health", "🏥"), ("财经", "finance", "💰"),
            ("购物", "shopping", "🛍️"), ("游戏", "game", "🎮"), ("新闻", "news", "📰"),
            ("中国", "china", "🇨🇳"), ("国际", "international", "🌐"), ("体育", "sports", "🏀"),
            ("戏曲", "traditional_opera", "🎭"), ("春晚", "spring_festival_gala", "🧨"),
            ("直播中国", "camera", "🏞️"), ("收藏频道", "favorite", "⭐")
        ]
        
        for display_name, channel_key, emoji in channel_mappings:
            channel_data = self.channel_manager.channels[channel_key]
            if not channel_data:
                continue
            
            if display_name in ["电·视·剧", "动·画·片", "纪·录·片", "收·音·机", "综艺频道",
                               "虎牙直播", "斗鱼直播", "解说频道", "音乐频道", "美食频道",
                               "旅游频道", "健康频道", "财经频道", "购物频道", "游戏频道",
                               "新闻频道", "中国综合", "国际频道", "体育频道", "戏曲频道",
                               "历届春晚", "景区直播", "收藏频道"]:
                # 特殊显示名称处理
                if display_name == "电视剧":
                    playlist.append("📺电·视·剧,#genre#")
                elif display_name == "动画片":
                    playlist.append("🐱动·画·片,#genre#")
                elif display_name == "纪录片":
                    playlist.append("🎥纪·录·片,#genre#")
                elif display_name == "收音机":
                    playlist.append("📻收·音·机,#genre#")
                elif display_name == "综艺":
                    playlist.append("🎭综艺频道,#genre#")
                elif display_name == "虎牙":
                    playlist.append("🐯虎牙直播,#genre#")
                elif display_name == "斗鱼":
                    playlist.append("🐠斗鱼直播,#genre#")
                elif display_name == "解说":
                    playlist.append("🎤解说频道,#genre#")
                elif display_name == "音乐":
                    playlist.append("🎵音乐频道,#genre#")
                elif display_name == "美食":
                    playlist.append("🍜美食频道,#genre#")
                elif display_name == "旅游":
                    playlist.append("✈️旅游频道,#genre#")
                elif display_name == "健康":
                    playlist.append("🏥健康频道,#genre#")
                elif display_name == "财经":
                    playlist.append("💰财经频道,#genre#")
                elif display_name == "购物":
                    playlist.append("🛍️购物频道,#genre#")
                elif display_name == "游戏":
                    playlist.append("🎮游戏频道,#genre#")
                elif display_name == "新闻":
                    playlist.append("📰新闻频道,#genre#")
                elif display_name == "中国":
                    playlist.append("🇨🇳中国综合,#genre#")
                elif display_name == "国际":
                    playlist.append("🌐国际频道,#genre#")
                elif display_name == "体育":
                    playlist.append("🏀体育频道,#genre#")
                elif display_name == "戏曲":
                    playlist.append("🎭戏曲频道,#genre#")
                elif display_name == "春晚":
                    playlist.append("🧨历届春晚,#genre#")
                elif display_name == "直播中国":
                    playlist.append("🏞️景区直播,#genre#")
                elif display_name == "收藏频道":
                    playlist.append("⭐收藏频道,#genre#")
            else:
                playlist.append(f"{emoji}{display_name}频道,#genre#")
            
            # 特殊排序处理
            if display_name in ["动画片", "纪录片", "综艺", "解说", "音乐", "游戏", "春晚", "直播中国"]:
                playlist.extend(sorted(set(correct_name_data(
                    self.channel_manager.corrections, channel_data
                ))))
            else:
                playlist.extend(sort_data(
                    self.channel_manager.dictionaries.get(display_name, []),
                    correct_name_data(self.channel_manager.corrections, channel_data)
                ))
            playlist.append('\n')
        
        # 其他频道
        playlist.append("📦其他频道,#genre#")
        playlist.extend(sorted(set(self.channel_manager.channels["other"])))
        playlist.append('\n')
        
        # 更新时间
        playlist.append("🕒更新时间,#genre#")
        playlist.extend(self._generate_version_info())
        playlist.append('\n')
        
        return playlist
    
    def build_lite_playlist(self) -> list:
        """构建精简版播放列表"""
        playlist = []
        
        # 央视频道
        playlist.append("🌐央视频道,#genre#")
        playlist.extend(sort_data(
            self.channel_manager.dictionaries.get("央视", []),
            correct_name_data(self.channel_manager.corrections, self.channel_manager.channels["yangshi"])
        ))
        playlist.append('\n')
        
        # 卫视频道
        playlist.append("📡卫视频道,#genre#")
        playlist.extend(sort_data(
            self.channel_manager.dictionaries.get("卫视", []),
            correct_name_data(self.channel_manager.corrections, self.channel_manager.channels["weishi"])
        ))
        playlist.append('\n')
        
        # 更新时间
        playlist.append("🕒更新时间,#genre#")
        playlist.extend(self._generate_version_info())
        playlist.append('\n')
        
        return playlist
    
    def build_custom_playlist(self) -> list:
        """构建定制版播放列表"""
        playlist = []
        
        # 央视频道
        playlist.append("🌐央视频道,#genre#")
        playlist.extend(sort_data(
            self.channel_manager.dictionaries.get("央视", []),
            correct_name_data(self.channel_manager.corrections, self.channel_manager.channels["yangshi"])
        ))
        playlist.append('\n')
        
        # 卫视频道
        playlist.append("📡卫视频道,#genre#")
        playlist.extend(sort_data(
            self.channel_manager.dictionaries.get("卫视", []),
            correct_name_data(self.channel_manager.corrections, self.channel_manager.channels["weishi"])
        ))
        playlist.append('\n')
        
        # 专享频道
        playlist.append("☕️专享央视,#genre#")
        playlist.extend(read_txt_to_array(f"{CONFIG['paths']['assets']['manual']}/优质央视.txt"))
        playlist.append('\n')
        
        playlist.append("🍹专享卫视,#genre#")
        playlist.extend(read_txt_to_array(f"{CONFIG['paths']['assets']['manual']}/优质卫视.txt"))
        playlist.append('\n')
        
        playlist.append("⚽️SPORTS,#genre#")
        playlist.extend(read_txt_to_array(f"{CONFIG['paths']['assets']['manual']}/sports.txt"))
        playlist.append('\n')
        
        # 体育赛事
        if self.channel_manager.channels["tyss"]:
            playlist.append("🏆️体育赛事,#genre#")
            playlist.extend(self.channel_manager.channels["tyss"])
            playlist.append('\n')
        
        # 咪咕赛事
        if self.channel_manager.channels["mgss"]:
            playlist.append("🏈咪咕赛事,#genre#")
            playlist.extend(self.channel_manager.channels["mgss"])
            playlist.append('\n')
        
        # 港澳台频道
        for display_name, channel_key, emoji in [
            ("香港", "hongkong", "🇭🇰"), ("澳门", "macau", "🇲🇴"), ("闽南", "minnan", "🇨🇳")
        ]:
            playlist.append(f"{emoji}{display_name}频道,#genre#")
            playlist.extend(sort_data(
                self.channel_manager.dictionaries.get(display_name, []),
                correct_name_data(self.channel_manager.corrections, self.channel_manager.channels[channel_key])
            ))
            playlist.append('\n')
        
        # 其他主频道（排除地方台）
        channel_mappings = [
            ("数字", "digital", "🔢"), ("电影", "movie", "🎬"), ("电视剧", "tv_drama", "📺"),
            ("动画片", "cartoon", "🐱"), ("纪录片", "documentary", "🎥"), ("收音机", "radio", "📻"),
            ("综艺", "variety", "🎭"), ("虎牙", "huya", "🐯"), ("斗鱼", "douyu", "🐠"),
            ("解说", "commentary", "🎤"), ("音乐", "music", "🎵"), ("美食", "food", "🍜"),
            ("旅游", "travel", "✈️"), ("健康", "health", "🏥"), ("财经", "finance", "💰"),
            ("购物", "shopping", "🛍️"), ("游戏", "game", "🎮"), ("新闻", "news", "📰"),
            ("中国", "china", "🇨🇳"), ("国际", "international", "🌐"), ("体育", "sports", "🏀"),
            ("戏曲", "traditional_opera", "🎭"), ("春晚", "spring_festival_gala", "🧨"),
            ("直播中国", "camera", "🏞️"), ("收藏频道", "favorite", "⭐")
        ]
        
        for display_name, channel_key, emoji in channel_mappings:
            channel_data = self.channel_manager.channels[channel_key]
            if not channel_data:
                continue
            
            # 特殊显示名称处理（与完整版相同）
            if display_name == "电视剧":
                playlist.append("📺电·视·剧,#genre#")
            elif display_name == "动画片":
                playlist.append("🐱动·画·片,#genre#")
            elif display_name == "纪录片":
                playlist.append("🎥纪·录·片,#genre#")
            elif display_name == "收音机":
                playlist.append("📻收·音·机,#genre#")
            elif display_name == "综艺":
                playlist.append("🎭综艺频道,#genre#")
            elif display_name == "虎牙":
                playlist.append("🐯虎牙直播,#genre#")
            elif display_name == "斗鱼":
                playlist.append("🐠斗鱼直播,#genre#")
            elif display_name == "解说":
                playlist.append("🎤解说频道,#genre#")
            elif display_name == "音乐":
                playlist.append("🎵音乐频道,#genre#")
            elif display_name == "美食":
                playlist.append("🍜美食频道,#genre#")
            elif display_name == "旅游":
                playlist.append("✈️旅游频道,#genre#")
            elif display_name == "健康":
                playlist.append("🏥健康频道,#genre#")
            elif display_name == "财经":
                playlist.append("💰财经频道,#genre#")
            elif display_name == "购物":
                playlist.append("🛍️购物频道,#genre#")
            elif display_name == "游戏":
                playlist.append("🎮游戏频道,#genre#")
            elif display_name == "新闻":
                playlist.append("📰新闻频道,#genre#")
            elif display_name == "中国":
                playlist.append("🇨🇳中国综合,#genre#")
            elif display_name == "国际":
                playlist.append("🌐国际频道,#genre#")
            elif display_name == "体育":
                playlist.append("🏀体育频道,#genre#")
            elif display_name == "戏曲":
                playlist.append("🎭戏曲频道,#genre#")
            elif display_name == "春晚":
                playlist.append("🧨历届春晚,#genre#")
            elif display_name == "直播中国":
                playlist.append("🏞️景区直播,#genre#")
            elif display_name == "收藏频道":
                playlist.append("⭐收藏频道,#genre#")
            else:
                playlist.append(f"{emoji}{display_name}频道,#genre#")
            
            # 特殊排序处理
            if display_name in ["动画片", "纪录片", "综艺", "解说", "音乐", "游戏", "春晚", "直播中国"]:
                playlist.extend(sorted(set(correct_name_data(
                    self.channel_manager.corrections, channel_data
                ))))
            else:
                playlist.extend(sort_data(
                    self.channel_manager.dictionaries.get(display_name, []),
                    correct_name_data(self.channel_manager.corrections, channel_data)
                ))
            playlist.append('\n')
        
        # 其他频道
        playlist.append("📦其他频道,#genre#")
        playlist.extend(sorted(set(self.channel_manager.channels["other"])))
        playlist.append('\n')
        
        # 更新时间
        playlist.append("🕒更新时间,#genre#")
        playlist.extend(self._generate_version_info())
        playlist.append('\n')
        
        return playlist
    
    def _generate_version_info(self) -> list:
        """生成版本信息"""
        beijing_time = get_beijing_time()
        formatted_time = beijing_time.strftime("%Y%m%d %H:%M:%S")
        
        # 生成今日推荐信息
        MTV1 = "💯推荐," + get_random_url(CONFIG["paths"]["files"]["today_recommend"])
        MTV2 = "🤫低调," + get_random_url(CONFIG["paths"]["files"]["today_recommend"])
        MTV3 = "🟢使用," + get_random_url(CONFIG["paths"]["files"]["today_recommend"])
        MTV4 = "⚠️禁止," + get_random_url(CONFIG["paths"]["files"]["today_recommend"])
        MTV5 = "🚫贩卖," + get_random_url(CONFIG["paths"]["files"]["today_recommend"])
        
        version = formatted_time + "," + get_random_url(CONFIG["paths"]["files"]["today_channel"])
        about = "👨潇然," + get_random_url(CONFIG["paths"]["files"]["today_channel"])
        
        return [version, about, MTV1, MTV2, MTV3, MTV4, MTV5] + \
               read_txt_to_array(CONFIG["paths"]["files"]["about"])

# ========= 主程序类 =========
class LiveSourceCollector:
    """直播源聚合处理主程序"""
    
    def __init__(self):
        # 初始化输出目录
        os.makedirs(CONFIG["paths"]["output"], exist_ok=True)
        print("创建输出目录: output")
        
        # 记录开始时间
        self.start_time = get_beijing_time()
        
        # 初始化管理器
        self.channel_manager = ChannelManager()
        self.playlist_generator = PlaylistGenerator(self.channel_manager)
    
    def run(self):
        """运行主程序"""
        print("🚀 开始处理直播源...")
        
        # 1. 处理URL源
        self._process_url_sources()
        
        # 2. 处理白名单
        self.channel_manager.process_whitelist()
        
        # 3. 处理AKTV
        self.channel_manager.process_aktv()
        
        # 4. 处理手工区源
        self.channel_manager.process_manual_sources()
        
        # 5. 处理体育赛事
        self._process_sports_channels()
        
        # 6. 生成播放列表文件
        self._generate_playlist_files()
        
        # 7. 生成M3U文件
        self._generate_m3u_files()
        
        # 8. 输出统计信息
        self._output_statistics()
        
        print("✅ 处理完成!")
    
    def _process_url_sources(self):
        """处理URL源"""
        urls = read_txt_to_array(CONFIG["paths"]["files"]["urls_daily"])
        print(f"📋 发现 {len(urls)} 个数据订阅源")
        
        for url in urls:
            if not url.startswith("http"):
                continue
            
            # 处理日期变量
            if "{MMdd}" in url:
                current_date_str = get_beijing_time().strftime("%m%d")
                url = url.replace("{MMdd}", current_date_str)
            if "{MMdd-1}" in url:
                yesterday_date_str = (get_beijing_time() - timedelta(days=1)).strftime("%m%d")
                url = url.replace("{MMdd-1}", yesterday_date_str)
            
            print(f"📡 处理URL: {url}")
            self.channel_manager.process_url(url)
    
    def _process_sports_channels(self):
        """处理体育赛事频道"""
        if not self.channel_manager.channels["tyss"]:
            return
        
        # 规范化日期格式
        normalized_tyss_lines = [normalize_date_to_md(s) for s in self.channel_manager.channels["tyss"]]
        
        # 过滤文本文件中的关键词
        filtered_txt = filter_lines(normalized_tyss_lines, CONFIG["processing"]["sports_exclude_txt"])
        
        # 去重并排序
        sorted_tyss_lines = custom_tyss_sort(set(filtered_txt))
        
        # 保存体育赛事TXT文件
        with open('output/tiyu.txt', 'w', encoding='utf-8') as f:
            f.write('\n'.join(sorted_tyss_lines))
        print(f"✅ 文本已生成: output/tiyu.txt")
        
        # 过滤HTML文件中的关键词
        filtered_html = filter_lines(sorted_tyss_lines, CONFIG["processing"]["sports_exclude_html"])
        
        # 生成HTML文件
        self.playlist_generator.generate_sports_html(filtered_html, 'output/tiyu.html')
        
        print(f"🏆 体育赛事处理完成：原始 {len(self.channel_manager.channels['tyss'])} 条，过滤后 {len(sorted_tyss_lines)} 条")
        
        # 更新体育赛事数据
        self.channel_manager.channels["tyss"] = sorted_tyss_lines
    
    def _generate_playlist_files(self):
        """生成播放列表文件"""
        print("📄 生成播放列表文件")
        
        # 生成各版本播放列表
        full_playlist = self.playlist_generator.build_full_playlist()
        lite_playlist = self.playlist_generator.build_lite_playlist()
        custom_playlist = self.playlist_generator.build_custom_playlist()
        
        # 保存文件
        output_files = {
            "output/full.txt": full_playlist,
            "output/lite.txt": lite_playlist,
            "output/custom.txt": custom_playlist,
            "output/others.txt": self.channel_manager.channels["other"]
        }
        
        for file_path, content in output_files.items():
            try:
                with open(file_path, 'w', encoding='utf-8') as f:
                    if isinstance(content, list):
                        f.write('\n'.join(content))
                    else:
                        f.write('\n'.join(content))
                print(f"✅ 播放列表已保存: {file_path}")
            except Exception as e:
                print(f"保存文件时发生错误 {file_path}: {e}")
    
    def _generate_m3u_files(self):
        """生成M3U文件"""
        txt_files = ["output/full.txt", "output/lite.txt", "output/custom.txt"]
        for txt_file in txt_files:
            m3u_file = txt_file.replace(".txt", ".m3u")
            self.playlist_generator.make_m3u(txt_file, m3u_file)
    
    def _output_statistics(self):
        """输出统计信息"""
        end_time = get_beijing_time()
        elapsed_time = end_time - self.start_time
        
        print("📊 生成统计信息")
        print(f"开始时间: {self.start_time.strftime('%Y%m%d %H:%M:%S')}")
        print(f"结束时间: {end_time.strftime('%Y%m%d %H:%M:%S')}")
        print(f"执行时间: {elapsed_time.seconds // 60} 分 {elapsed_time.seconds % 60} 秒")
        
        # 去重统计信息
        processed_urls_count = len(self.channel_manager.processed_urls)
        blacklist_urls_count = len(self.channel_manager.blacklist)
        total_processed_urls = processed_urls_count + blacklist_urls_count
        
        print(f"📊 去重统计信息:")
        print(f"   处理的唯一URL数: {processed_urls_count}")
        print(f"   黑名单URL数: {blacklist_urls_count}")
        print(f"   总处理URL数: {total_processed_urls}")
        
        if total_processed_urls > 0:
            duplication_rate = (1 - processed_urls_count / total_processed_urls) * 100
            print(f"   🔄 去重率: {duplication_rate:.1f}%")
        else:
            print(f"   🔄 去重率: N/A")
        
        # 其他统计信息
        print(f"黑名单行数: {blacklist_urls_count}")
        print(f"完整版行数: {len(self.playlist_generator.build_full_playlist())}")
        print(f"其它源行数: {len(self.channel_manager.channels['other'])}")

# ========= 主程序入口 =========
if __name__ == "__main__":
    collector = LiveSourceCollector()
    collector.run()
    print("🎉 所有处理完成!")