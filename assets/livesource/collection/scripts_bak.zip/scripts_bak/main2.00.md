📺 直播源聚合处理工具 v2.00 - 详细维护手册

📋 项目概述

项目名称: LiveSource-Collector 优化版
版本: v2.00
作者: 潇然
维护日期: 2025-01-01

本文档详细说明脚本的所有文件格式、处理逻辑、分类管理和配置方法。

---

📂 一、项目目录结构详解

1.1 核心目录结构 (assets/livesource/)

```
assets/livesource/
├── 📁 主频道/                     # 专业频道分类字典
│   ├── 📄 CCTV.txt                # 央视频道字典 (用于排序)
│   ├── 📄 卫视.txt                # 卫视频道字典 (用于匹配+排序)
│   ├── 📄 体育.txt                # 体育频道字典 (用于匹配+排序)
│   ├── 📄 体育赛事.txt            # 体育赛事关键词字典 (用于模糊匹配)
│   ├── 📄 咪咕赛事.txt            # 咪咕赛事关键词字典 (用于模糊匹配)
│   ├── 📄 电影.txt                # 电影频道字典
│   ├── 📄 电视剧.txt              # 电视剧频道字典
│   ├── 📄 纪录片.txt              # 纪录片频道字典
│   ├── 📄 动画片.txt              # 动画片频道字典
│   ├── 📄 收音机.txt              # 收音机频道字典
│   ├── 📄 综艺.txt                # 综艺频道字典
│   ├── 📄 虎牙.txt                # 虎牙直播字典
│   ├── 📄 斗鱼.txt                # 斗鱼直播字典
│   ├── 📄 解说.txt                # 解说频道字典
│   ├── 📄 音乐.txt                # 音乐频道字典
│   ├── 📄 美食.txt                # 美食频道字典
│   ├── 📄 旅游.txt                # 旅游频道字典
│   ├── 📄 健康.txt                # 健康频道字典
│   ├── 📄 财经.txt                # 财经频道字典
│   ├── 📄 购物.txt                # 购物频道字典
│   ├── 📄 游戏.txt                # 游戏频道字典
│   ├── 📄 新闻.txt                # 新闻频道字典
│   ├── 📄 中国.txt                # 中国综合频道字典
│   ├── 📄 国际.txt                # 国际频道字典
│   ├── 📄 戏曲.txt                # 戏曲频道字典
│   ├── 📄 春晚.txt                # 春晚频道字典
│   ├── 📄 直播中国.txt            # 景区直播字典
│   ├── 📄 收藏频道.txt            # 收藏频道字典
│   └── 📄 数字.txt                # 数字频道字典
│
├── 📁 地方台/                     # 地方台分类字典
│   ├── 📄 北京.txt                # 北京频道字典
│   ├── 📄 上海.txt                # 上海频道字典
│   ├── 📄 广东.txt                # 广东频道字典
│   ├── 📄 江苏.txt                # 江苏频道字典
│   ├── 📄 浙江.txt                # 浙江频道字典
│   ├── 📄 山东.txt                # 山东频道字典
│   ├── 📄 四川.txt                # 四川频道字典
│   ├── 📄 河南.txt                # 河南频道字典
│   ├── 📄 湖南.txt                # 湖南频道字典
│   ├── 📄 重庆.txt                # 重庆频道字典
│   ├── 📄 天津.txt                # 天津频道字典
│   ├── 📄 湖北.txt                # 湖北频道字典
│   ├── 📄 安徽.txt                # 安徽频道字典
│   ├── 📄 福建.txt                # 福建频道字典
│   ├── 📄 辽宁.txt                # 辽宁频道字典
│   ├── 📄 陕西.txt                # 陕西频道字典
│   ├── 📄 河北.txt                # 河北频道字典
│   ├── 📄 江西.txt                # 江西频道字典
│   ├── 📄 广西.txt                # 广西频道字典
│   ├── 📄 云南.txt                # 云南频道字典
│   ├── 📄 山西.txt                # 山西频道字典
│   ├── 📄 黑龙江.txt              # 黑龙江频道字典
│   ├── 📄 吉林.txt                # 吉林频道字典
│   ├── 📄 贵州.txt                # 贵州频道字典
│   ├── 📄 甘肃.txt                # 甘肃频道字典
│   ├── 📄 内蒙.txt                # 内蒙古频道字典
│   ├── 📄 新疆.txt                # 新疆频道字典
│   ├── 📄 海南.txt                # 海南频道字典
│   ├── 📄 宁夏.txt                # 宁夏频道字典
│   ├── 📄 青海.txt                # 青海频道字典
│   ├── 📄 西藏.txt                # 西藏频道字典
│   ├── 📄 香港.txt                # 香港频道字典
│   ├── 📄 澳门.txt                # 澳门频道字典
│   └── 📄 台湾.txt                # 台湾频道字典
│
├── 📁 手工区/                     # 🛠️ 手工维护的高质量源
│   ├── 📄 优质央视.txt            # ⭐ 专享央视源 (独立分类)
│   ├── 📄 优质卫视.txt            # ⭐ 专享卫视源 (独立分类)
│   ├── 📄 sports.txt              # ⚽ 体育赛事源 (独立分类)
│   ├── 📄 浙江频道.txt            # 🧵 浙江手工源 (追加到自动源)
│   ├── 📄 广东频道.txt            # 🐯 广东手工源 (追加到自动源)
│   ├── 📄 湖北频道.txt            # 🏯 湖北手工源 (追加到自动源)
│   ├── 📄 上海频道.txt            # 🏙️ 上海手工源 (追加到自动源)
│   ├── 📄 江苏频道.txt            # 🎐 江苏手工源 (追加到自动源)
│   ├── 📄 AKTV.txt                # 💓 AKTV直播源 (混合处理)
│   ├── 📄 今日推荐.txt            # 💯 今日推荐源 (随机选择)
│   ├── 📄 今日推台.txt            # 🕒 版本信息链接源
│   └── 📄 about.txt               # ℹ️ 关于信息文件
│
├── 📁 blacklist/                  # 🚫 黑名单管理系统
│   ├── 📄 blacklist_auto.txt      # 🔄 自动黑名单 (系统生成)
│   ├── 📄 blacklist_manual.txt    # ✏️ 手动黑名单 (人工维护)
│   └── 📄 whitelist_auto.txt      # ✅ 白名单 (高质量源记录)
│
├── 📄 corrections_name.txt        # 🔧 频道名称纠错字典
├── 📄 logo.txt                    # 🖼️ 频道Logo对应关系
└── 📄 urls-daily.txt              # 🌐 每日更新的数据源URL列表
```

1.2 输出目录结构 (output/)

```
output/
├── 📄 full.txt                    # 📦 完整版播放列表 (TXT格式)
├── 📄 full.m3u                    # 📦 完整版播放列表 (M3U格式)
├── 📄 lite.txt                    # 🎯 精简版播放列表 (TXT格式)
├── 📄 lite.m3u                    # 🎯 精简版播放列表 (M3U格式)
├── 📄 custom.txt                  # 🛠️ 定制版播放列表 (TXT格式)
├── 📄 custom.m3u                  # 🛠️ 定制版播放列表 (M3U格式)
├── 📄 others.txt                  # 📦 未分类频道列表
├── 📄 tiyu.html                   # 🏆 体育赛事网页版
└── 📄 tiyu.txt                    # 🏆 体育赛事文本版
```

---

📝 二、文件格式详解

2.1 字典文件格式 (*.txt)

格式: 每行一个频道名称，按期望的排序顺序排列

📄 示例 (CCTV.txt):

```txt
CCTV1
CCTV2
CCTV3
CCTV4
CCTV5
CCTV5+
CCTV6
CCTV7
CCTV8
CCTV9
CCTV10
CCTV11
CCTV12
CCTV13
CCTV14
CCTV15
CCTV16
CCTV17
CCTV4K
CCTV8K
```

📄 示例 (卫视.txt):

```txt
北京卫视
东方卫视
天津卫视
重庆卫视
河北卫视
山西卫视
辽宁卫视
吉林卫视
黑龙江卫视
江苏卫视
浙江卫视
安徽卫视
福建卫视
江西卫视
山东卫视
河南卫视
湖北卫视
湖南卫视
广东卫视
广西卫视
海南卫视
四川卫视
贵州卫视
云南卫视
陕西卫视
甘肃卫视
青海卫视
内蒙古卫视
宁夏卫视
新疆卫视
西藏卫视
```

2.2 关键词字典格式 (用于模糊匹配)

格式: 每行一个关键词，频道名称包含任意关键词即匹配

📄 示例 (体育赛事.txt):

```txt
中超
英超
西甲
意甲
德甲
法甲
欧冠
亚冠
世界杯
欧洲杯
亚洲杯
奥运会
世锦赛
马拉松
篮球
足球
排球
乒乓球
羽毛球
网球
游泳
田径
```

2.3 手工区源文件格式

格式: 标准频道行格式，但不经过 process_channel_line 处理

📄 示例 (浙江频道.txt):

```txt
浙江卫视,http://example.com/zjws
浙江卫视高清,http://example.com/zjwshd
钱江都市,http://example.com/qjds
浙江影视娱乐,http://example.com/zjysyl
浙江教育科技,http://example.com/zjjy
```

2.4 专享源文件格式 (独立分类)

格式: 标准频道行格式，直接读取作为独立分类

📄 示例 (优质央视.txt):

```txt
CCTV1,http://example.com/cctv1-hq
CCTV2,http://example.com/cctv2-hq
CCTV3,http://example.com/cctv3-hq
CCTV4K,http://example.com/cctv4k-hq
CCTV5+,http://example.com/cctv5plus-hq
CCTV8,http://example.com/cctv8-hq
CCTV13,http://example.com/cctv13-hq
```

2.5 黑名单文件格式

📄 示例 (blacklist_manual.txt):

```txt
黑名单频道1,http://bad-url1.com/live
黑名单频道2,http://bad-url2.com/stream
失效频道,http://expired-url.com/tv
广告频道,http://ad-channel.com/live
```

2.6 白名单文件格式

📄 示例 (whitelist_auto.txt):

```txt
RespoTime,whitelist,#genre#
2024-12-01 14:30:00
10ms,CCTV1,http://fast-server.com/cctv1
20ms,CCTV2,http://fast-server.com/cctv2
150ms,湖南卫视,http://fast-server.com/hunan
5000ms,慢速频道,http://slow-server.com/tv  # 响应太慢，不会被采用
```

2.7 频道名称纠错字典格式

📄 示例 (corrections_name.txt):

```txt
# 格式: 正确名称,错误名称1,错误名称2,错误名称3
CCTV1,CCTV-1,CCTV1综合,CCTV1综合频道
CCTV2,CCTV-2,CCTV2财经,CCTV2财经频道
湖南卫视,湖南电视台,湖南卫视频道
浙江卫视,浙江电视台,浙江卫视频道,浙江卫视HD
```

2.8 Logo对应关系文件格式

📄 示例 (logo.txt):

```txt
CCTV1,https://example.com/logos/cctv1.png
CCTV2,https://example.com/logos/cctv2.png
湖南卫视,https://example.com/logos/hunan.png
浙江卫视,https://example.com/logos/zhejiang.png
东方卫视,https://example.com/logos/dongfang.png
```

2.9 数据源URL列表格式

📄 示例 (urls-daily.txt):

```txt
# 每日更新的直播源URL列表
https://raw.githubusercontent.com/user1/iptv/main/live.m3u
https://raw.githubusercontent.com/user2/tv/main/tv.txt
https://example.com/daily/{MMdd}.m3u           # 日期变量会自动替换
https://example.com/yesterday/{MMdd-1}.txt      # 昨天日期
http://iptv-source.com/live.m3u8
https://live-source.net/channels.txt
```

---

🔧 三、如何增删频道分类

3.1 添加新的频道分类（6步法）

步骤 1️⃣: 添加存储变量

在代码的频道分类存储变量定义部分添加新的列表变量：

```python
# 在 yangshi_lines, weishi_lines 等变量后面添加
new_category_lines = []      # 存储新分类的数据
```

步骤 2️⃣: 添加字典文件

在 assets/livesource/主频道/ 目录下创建新的字典文件：

```bash
# 创建字典文件
echo "频道1\n频道2\n频道3\n频道4" > assets/livesource/主频道/新分类.txt
```

步骤 3️⃣: 加载字典

在频道字典文件读取部分添加字典加载：

```python
# 在 yangshi_dictionary, weishi_dictionary 等后面添加
new_category_dictionary = read_txt_to_array('assets/livesource/主频道/新分类.txt')
```

步骤 4️⃣: 添加分类处理逻辑

在 process_channel_line 函数中添加分类判断逻辑：

```python
# 在相应的分类判断区域添加（注意顺序）
elif channel_name in new_category_dictionary and check_url_existence(new_category_lines, channel_address):
    new_category_lines.append(process_name_string(line.strip()))
```

步骤 5️⃣: 添加工区支持（可选）

如果需要手工区支持，创建手工区文件：

```bash
# 创建手工区文件
touch assets/livesource/手工区/新分类.txt
```

并在手工区处理部分添加：

```python
new_category_lines += read_txt_to_array('assets/livesource/手工区/新分类.txt')
```

步骤 6️⃣: 添加播放列表输出

在播放列表生成部分添加输出格式：

```python
# 在完整版播放列表中添加
["🎨新分类频道,#genre#"] + sort_data(new_category_dictionary, 
    set(correct_name_data(corrections_name, new_category_lines))) + ['\n'] + \
```

3.2 删除频道分类（4步法）

步骤 1️⃣: 移除存储变量

删除对应的列表变量定义：

```python
# 删除这行
old_category_lines = []      # 要删除的分类
```

步骤 2️⃣: 移除字典加载

删除字典加载代码：

```python
# 删除这行
old_category_dictionary = read_txt_to_array('assets/livesource/主频道/旧分类.txt')
```

步骤 3️⃣: 移除分类处理逻辑

在 process_channel_line 函数中删除对应的 elif 分支。

步骤 4️⃣: 移除播放列表输出

在播放列表生成部分删除对应的输出行。

3.3 修改分类名称（3步法）

步骤 1️⃣: 修改字典文件名

```bash
mv assets/livesource/主频道/旧名称.txt assets/livesource/主频道/新名称.txt
```

步骤 2️⃣: 修改代码中的字典引用

```python
# 修改字典加载
new_name_dictionary = read_txt_to_array('assets/livesource/主频道/新名称.txt')

# 修改分类判断
elif channel_name in new_name_dictionary and check_url_existence(new_name_lines, channel_address):
```

步骤 3️⃣: 修改播放列表输出

```python
["🎯新名称频道,#genre#"] + sort_data(new_name_dictionary, 
    set(correct_name_data(corrections_name, new_name_lines))) + ['\n'] + \
```

---

⚙️ 四、配置设置详解

4.1 黑名单管理系统配置

🚫 自动黑名单 (blacklist_auto.txt)

作用: 系统自动检测并添加的失效源
更新频率: 每日自动更新
格式要求: 频道名称,URL

维护方法:

```bash
# 查看自动黑名单
cat assets/livesource/blacklist/blacklist_auto.txt

# 清空自动黑名单（慎用）
> assets/livesource/blacklist/blacklist_auto.txt
```

✏️ 手动黑名单 (blacklist_manual.txt)

作用: 人工维护的不良源列表
更新方式: 手动编辑
格式要求: 频道名称,URL

添加方法:

```bash
# 添加单个黑名单
echo "不良频道,http://bad-channel.com/live" >> assets/livesource/blacklist/blacklist_manual.txt

# 批量添加
cat >> assets/livesource/blacklist/blacklist_manual.txt << EOF
频道1,http://bad1.com
频道2,http://bad2.com
频道3,http://bad3.com
EOF
```

✅ 白名单 (whitelist_auto.txt)

作用: 记录高质量源的响应时间
生成方式: 自动检测生成
格式要求: 响应时间,频道名称,URL

响应时间阈值:

· ✅ < 2000ms: 会被采用
· ⚠️ 2000-5000ms: 可能被采用
· ❌ > 5000ms: 不会被采用

4.2 频道名称清理规则配置

🧹 清理规则 (removal_list 变量)

在代码中修改 removal_list 变量来调整清理规则：

```python
removal_list = [
    "_电信", "电信", "频道", "频陆", "备陆",
    "高清", "超清", "标清", "HD", "[HD]", "(HD)",
    "4K", "(4K)", "{4K}", "<4K>",
    "1080", "720", "480",
    "咪咕", "闽特", "高特",
    # ... 可以自定义添加或删除
]
```

🔧 名称纠错规则 (corrections_name.txt)

格式: 正确名称,错误名称1,错误名称2,...

示例配置:

```txt
# 央视纠错
CCTV1,CCTV-1,CCTV1综合,CCTV1综合频道,CCTV1高清
CCTV2,CCTV-2,CCTV2财经,CCTV2财经频道
CCTV5+,CCTV5PLUS,CCTV5加,CCTV5+

# 卫视纠错
湖南卫视,湖南电视台,湖南卫视频道,湖南卫视HD
浙江卫视,浙江电视台,浙江卫视频道,浙江卫视高清

# 地方台纠错
北京卫视,北京电视台,北京卫视频道
东方卫视,上海卫视,东方电视台
```

4.3 播放列表输出配置

📊 三种播放列表类型

1. 完整版 (full.txt): 包含所有分类和源
2. 精简版 (lite.txt): 只包含央视、卫视和更新时间
3. 定制版 (custom.txt): 自定义的分类组合

🎨 修改分类图标和顺序

在播放列表生成部分修改：

```python
# 修改分类标题和图标
["🌐央视频道,#genre#"] + sort_data(...) + ['\n'] + \
["📡卫视频道,#genre#"] + sort_data(...) + ['\n'] + \
["🏛️北京频道,#genre#"] + sort_data(...) + ['\n'] + \
```

可用图标示例:

· 🌐 📡 🏛️ 🏙️ 🐯 🎐 🧵 ⛰️ 🐼 🐘 ⛩️ 🌶️ 🏞️ 🚢 🏯 🌾 🌊 🔥 💃 ☁️ 🏮 🐻 🎎 🐫 🐮 🍇 🏝️ 🕌 🐑 🐐

🔄 修改排序方式

修改 sort_data 函数调用：

```python
# 默认: 字典排序 + 去重 + 名称修正
sort_data(字典名, set(correct_name_data(corrections_name, 数据列表)))

# 可选: 只去重排序
sorted(set(correct_name_data(corrections_name, 数据列表)))

# 可选: 只字典排序
sort_data(字典名, correct_name_data(corrections_name, 数据列表))
```

4.4 手工区管理配置

🛠️ 手工区文件类型

1. 追加型: 追加到自动采集的数据中
   · 文件位置: assets/livesource/手工区/[地区]频道.txt
   · 处理方式: 地区_lines += read_txt_to_array(...)
   · 特点: 不去重，不检查黑名单
2. 独立型: 作为独立分类
   · 文件位置: assets/livesource/手工区/优质*.txt
   · 处理方式: read_txt_to_array(...) 直接输出
   · 特点: 独立分类，不与自动源混合
3. 混合型: 经过标准处理
   · 文件位置: assets/livesource/手工区/AKTV.txt
   · 处理方式: process_channel_line(line)
   · 特点: 会检查黑名单，会去重

📝 添加工区源

```bash
# 1. 创建或编辑手工区文件
vi assets/livesource/手工区/浙江频道.txt

# 2. 添加频道源（格式: 频道名称,URL）
浙江卫视,http://fast-server.com/zjws
浙江卫视高清,http://fast-server.com/zjwshd
钱江都市,http://fast-server.com/qjds

# 3. 确保代码中有对应的处理
# 在手工区处理部分应该有：
# zhejiang_lines += read_txt_to_array('assets/livesource/手工区/浙江频道.txt')
```

🗑️ 删除工区源

```bash
# 1. 从手工区文件中删除特定行
sed -i '/不良频道/d' assets/livesource/手工区/浙江频道.txt

# 2. 或清空整个文件
> assets/livesource/手工区/浙江频道.txt
```

4.5 今日推荐配置

💯 今日推荐源管理

文件位置: assets/livesource/手工区/今日推荐.txt
格式: 每行一个频道源 (频道名称,URL)

配置方法:

```bash
# 添加推荐源
echo "CCTV1高清,http://best-server.com/cctv1" >> assets/livesource/手工区/今日推荐.txt
echo "湖南卫视超清,http://best-server.com/hunan" >> assets/livesource/手工区/今日推荐.txt

# 查看当前推荐源
cat assets/livesource/手工区/今日推荐.txt
```

工作原理:

· 每次运行脚本时随机选择一个源作为"今日推荐"
· 同时从同一个文件中随机选择5个源用于"推荐"、"低调"、"使用"、"禁止"、"贩卖"

🕒 版本信息配置

文件位置: assets/livesource/手工区/今日推台.txt
格式: 每行一个视频链接

配置方法:

```bash
# 更新版本信息视频链接
echo "https://example.com/video1.mp4" > assets/livesource/手工区/今日推台.txt
echo "https://example.com/video2.mp4" >> assets/livesource/手工区/今日推台.txt
```

---

🔍 五、调试和故障排除

5.1 常见问题排查

❓ 问题: 频道没有被正确分类

检查步骤:

1. 检查频道名称是否在对应的字典文件中
2. 检查频道名称清理规则是否过度清理
3. 查看 output/others.txt 是否在该文件中
4. 检查黑名单是否误杀

调试命令:

```bash
# 查看未分类的频道
cat output/others.txt | grep "频道名称"

# 检查字典匹配
grep "频道名称" assets/livesource/主频道/对应字典.txt
```

❓ 问题: 播放列表中有重复频道

检查步骤:

1. 检查手工区源是否与自动源重复
2. 检查不同分类中是否有相同频道
3. 检查去重逻辑是否正常工作

调试命令:

```bash
# 查找重复URL
cat output/full.txt | grep -o 'http[^,]*' | sort | uniq -d

# 统计每个分类的频道数
echo "央视: $(grep -c '^CCTV' output/full.txt)"
echo "卫视: $(grep -c '卫视' output/full.txt)"
```

❓ 问题: 频道名称显示不正常

检查步骤:

1. 检查 corrections_name.txt 纠错规则
2. 检查 removal_list 清理规则
3. 检查繁体转简体是否正常

调试命令:

```bash
# 查看原始频道名称
cat output/others.txt | head -20

# 测试名称清理
python3 -c "
from opencc import OpenCC
cc = OpenCC('t2s')
print(cc.convert('頻道名稱'))
"
```

5.2 日志分析

📊 运行日志解读

```
🔴 黑名单统计信息:
   自动维护: 150 条
   手动维护: 50 条
   合并去重: 180 条

📋 发现 25 个数据订阅源
📡 处理URL: https://example.com/live.m3u
行数: 1000

🟢 处理白名单自动文件...
   读取到 500 条记录
   有效白名单记录: 120 条

🏆 体育赛事处理完成：原始 200 条，过滤后 150 条

📊 去重统计信息:
   处理的唯一URL数: 5000
   黑名单URL数: 180
   总处理URL数: 5180
   🔄 去重率: 3.5%
```

🚨 错误日志处理

```python
# 常见错误及处理
❌ 文件未找到: assets/livesource/主频道/xxx.txt
处理: 创建缺失的字典文件

❌ 读取文件错误: UnicodeDecodeError
处理: 检查文件编码，确保是UTF-8

❌ 处理URL时发生错误: timeout
处理: 网络问题，检查URL是否可访问

❌ response_time转换失败
处理: 检查whitelist_auto.txt格式
```

5.3 性能优化

⚡ 提高处理速度

1. 减少源数量: 编辑 urls-daily.txt 移除慢速源
2. 调整超时时间: 修改 get_http_response 的 timeout 参数
3. 优化字典文件: 移除不用的分类字典

💾 减少内存使用

1. 分块处理: 大量数据时分块处理
2. 及时清理: 处理完的数据及时写入文件
3. 使用生成器: 对于大量数据使用生成器

---

🚀 六、高级功能配置

6.1 自定义体育赛事处理

🏆 体育赛事关键词过滤

修改 keywords_to_exclude_tiyu_txt 和 keywords_to_exclude_tiyu:

```python
# 文本版过滤关键词
keywords_to_exclude_tiyu_txt = [
    "玉玉软件", "榴芒电视", "公众号",
    "麻豆", "「回看」", "广告",
    # 添加自定义关键词
    "不良网站", "盗版源"
]

# HTML版过滤关键词（更严格）
keywords_to_exclude_tiyu = [
    "玉玉软件", "榴芒电视", "公众号",
    "咪视通", "麻豆", "「回看」",
    # 添加自定义关键词
    "测试频道", "无效源"
]
```

📅 日期格式规范化

修改 normalize_date_to_md 函数支持更多日期格式：

```python
def normalize_date_to_md(text):
    text = text.strip()
    
    # 添加新的日期格式支持
    # MM-DD
    text = re.sub(r'^(\d{1,2})-(\d{1,2})(.*)', r'\1-\2\3', text)
    # MM.DD
    text = re.sub(r'^(\d{1,2})\.(\d{1,2})(.*)', r'\1-\2\3', text)
    # 中文"月""日"
    text = re.sub(r'^(\d{1,2})月(\d{1,2})日(.*)', r'\1-\2\3', text)
    
    return text
```

6.2 自定义输出格式

🎯 修改播放列表分组

在播放列表生成部分调整分组顺序和标题：

```python
# 建议的分组顺序（按用户使用频率）
all_lines_custom = [
    ["🌐央视频道,#genre#"] + ...,
    ["📡卫视频道,#genre#"] + ...,
    ["🇨🇳中国综合,#genre#"] + ...,
    ["📰新闻频道,#genre#"] + ...,
    ["⚽️体育频道,#genre#"] + ...,
    ["🎬电影频道,#genre#"] + ...,
    ["📺电视剧,#genre#"] + ...,
    ["🎭综艺频道,#genre#"] + ...,
    # ... 其他分类
]
```

🖼️ 自定义Logo配置

编辑 logo.txt 文件为频道指定Logo：

```txt
# 格式: 频道名称,LogoURL
CCTV1,https://example.com/logos/cctv1.png
CCTV2,https://example.com/logos/cctv2.png
湖南卫视,https://example.com/logos/hunan.png
浙江卫视,https://example.com/logos/zhejiang.png

# 如果没有Logo，留空或使用默认
未知频道,
```

6.3 自动化维护脚本

📅 每日自动更新

创建定时任务（cron job）自动运行：

```bash
# 编辑crontab
crontab -e

# 添加每日凌晨3点运行
0 3 * * * cd /path/to/script && python3 main.py

# 添加日志记录
0 3 * * * cd /path/to/script && python3 main.py >> /var/log/iptv-update.log 2>&1
```

🔄 自动备份配置

创建备份脚本：

```bash
#!/bin/bash
# backup-config.sh
DATE=$(date +%Y%m%d)
BACKUP_DIR="/backup/iptv-config-$DATE"

mkdir -p $BACKUP_DIR
cp -r assets/livesource/ $BACKUP_DIR/
cp *.py $BACKUP_DIR/
echo "备份完成: $BACKUP_DIR"
```

---

📚 七、附录：常用命令速查

7.1 文件管理命令

```bash
# 查看分类统计
grep -c "^[^,]*,[^,]*$" output/full.txt

# 查找特定频道
grep "CCTV1" output/full.txt

# 统计URL数量
grep -o 'http[^,]*' output/full.txt | wc -l

# 检查重复URL
grep -o 'http[^,]*' output/full.txt | sort | uniq -d | wc -l
```

7.2 维护命令

```bash
# 更新手工区源
vi assets/livesource/手工区/优质央视.txt

# 添加黑名单
echo "不良频道,http://bad.com" >> assets/livesource/blacklist/blacklist_manual.txt

# 清空日志
> output/others.txt

# 重新生成所有列表
rm output/*.txt output/*.m3u && python3 main.py
```

7.3 调试命令

```bash
# 查看处理日志
tail -f /var/log/iptv-update.log

# 测试单个URL
python3 -c "
import urllib.request
req = urllib.request.Request('http://example.com/live.m3u')
response = urllib.request.urlopen(req)
print(response.read().decode('utf-8')[:500])
"

# 检查Python依赖
python3 -c "import opencc; print('opencc OK')"
```

---

🎯 总结

📋 维护检查清单

· ✅ 每日检查 urls-daily.txt 中的源是否可用
· ✅ 定期更新手工区优质源
· ✅ 检查黑名单，移除误杀的源
· ✅ 更新频道名称纠错字典
· ✅ 备份重要配置文件
· ✅ 监控脚本运行日志

🔄 版本更新流程

1. 备份当前配置和脚本
2. 下载新版本脚本
3. 对比并合并配置文件
4. 测试新版本功能
5. 更新文档和说明

📞 技术支持

· 查看详细日志: cat /var/log/iptv-update.log
· 检查错误信息: 查看脚本输出的错误信息
· 验证配置文件: 确保所有文件格式正确
· 测试网络连接: 确保所有源URL可访问

---

最后更新: 2025-01-01
维护人员: 系统管理员
文档版本: v2.00.1

如有问题，请检查日志文件和配置文件格式。