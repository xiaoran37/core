直播源聚合处理工具 v2.00 维护说明书

📖 文档概述

本文档详细说明如何维护和管理直播源聚合处理工具的分类系统、排序规则和输出格式。适合系统管理员、维护人员和二次开发者使用。

---

📋 目录

1. 系统架构
2. 分类管理
3. 排序控制
4. 格式配置
5. 数据源管理
6. 高级配置
7. 故障排除
8. 附录

---

1. 系统架构

1.1 核心处理流程

```
原始数据 → URL预处理 → 全局去重 → 名称标准化 → 分类分发 → 分组去重 → 排序输出
```

1.2 文件结构

```
live-source-collector/
├── main.py                    # 主程序
├── assets/
│   └── livesource/
│       ├── 主频道/           # 主要分类字典
│       ├── 地方台/           # 地方台分类字典
│       ├── blacklist/        # 黑名单
│       ├── 手工区/           # 手工维护源
│       └── urls-daily.txt    # 数据源URL列表
├── output/                   # 输出目录
├── config/                   # 配置文件（可选）
└── docs/                     # 文档
```

---

2. 分类管理

2.1 分类配置字典

核心配置文件：category_configs 字典

2.1.1 格式说明

```python
category_configs = {
    "分类名称": (
        数据列表变量,      # 存储该分类数据的Python变量名
        字典文件对象,      # 排序字典，None表示按字母排序
        keep_multiple,     # True=保留多个源，False=只保留最佳源
        max_sources        # 每个频道最多保留的源数量
    ),
    # 示例：
    "央视频道": (yangshi_lines, yangshi_dictionary, True, 3),
    "北京频道": (beijing_lines, beijing_dictionary, False, 1),
}
```

2.1.2 参数详解

参数 类型 说明 建议值
数据列表变量 Python变量 存储分类数据的列表 如 yangshi_lines
字典文件对象 列表或None 排序用的字典 从txt文件加载
keep_multiple Boolean 是否保留多个源 重要分类=True
max_sources Integer 最多保留源数量 1-5

2.2 添加新分类

步骤1：定义数据存储变量

```python
# 在 "频道分类存储变量定义" 区域（约50行）添加
your_category_lines = []  # 新分类数据存储
```

步骤2：创建排序字典文件

```txt
# 创建：assets/livesource/主频道/新分类.txt
# 按期望顺序排列频道名称
频道A
频道B
频道C
...
```

步骤3：加载字典文件

```python
# 在字典文件读取部分（约280行）添加
your_category_dictionary = read_txt_to_array('assets/livesource/主频道/新分类.txt')
```

步骤4：添加分发逻辑

```python
# 在 process_channel_line() 函数中（约300行）添加
elif channel_name in your_category_dictionary:
    your_category_lines.append(process_name_string(line.strip()))
```

步骤5：配置分类参数

```python
# 在 category_configs 字典（约740行）添加
"新分类": (your_category_lines, your_category_dictionary, True, 2),
```

步骤6：添加emoji图标

```python
# 在 build_playlist() 函数的 emoji_map（约810行）添加
"新分类": "🎯",  # 选择合适的emoji
```

步骤7：添加到播放列表

```python
# 在 build_playlist() 函数的 categories_to_include 中添加
if playlist_type == "full":
    categories_to_include = [
        # ... 原有分类
        "新分类",  # 新增
    ]
```

2.3 删除分类

方法A：完全删除

```python
# 步骤1：从 category_configs 中删除
# del category_configs["要删除的分类"]

# 步骤2：从 emoji_map 中删除
# del emoji_map["要删除的分类"]

# 步骤3：从 categories_to_include 中删除
```

方法B：暂时禁用（推荐）

```python
# 在 categories_to_include 中注释掉
if playlist_type == "full":
    categories_to_include = [
        "央视频道",
        "卫视频道",
        # "要禁用的分类",  # 注释此行
        "上海频道",
    ]
```

2.4 修改分类参数

2.4.1 修改保留源数量

```python
# 修改前
"北京频道": (beijing_lines, beijing_dictionary, False, 1),

# 修改后（保留3个源）
"北京频道": (beijing_lines, beijing_dictionary, True, 3),
```

2.4.2 修改排序方式

```python
# 从字典排序改为字母排序
"河南频道": (henan_lines, None, False, 1),

# 从字母排序改为字典排序
"综艺频道": (variety_lines, variety_dictionary, False, 1),
```

2.5 分类配置示例

2.5.1 重要分类（保留多个源）

```python
"央视频道": (yangshi_lines, yangshi_dictionary, True, 3),
"卫视频道": (weishi_lines, weishi_dictionary, True, 3),
"香港频道": (hongkong_lines, hongkong_dictionary, True, 2),
```

2.5.2 普通分类（只保留最佳源）

```python
"电影频道": (movie_lines, movie_dictionary, False, 1),
"动画片频道": (cartoon_lines, cartoon_dictionary, False, 1),
"其他频道": (other_lines, None, False, 1),
```

2.5.3 特色分类配置

```python
# 4K专区：保留2个高质量源
"4K专区": (ultra_hd_lines, ultra_hd_dictionary, True, 2),

# 体育赛事：特殊处理，不在此配置中
# 见 sports_lines 和 tyss_lines 的特殊处理逻辑
```

---

3. 排序控制

3.1 排序字典文件规范

文件位置

```
assets/livesource/
├── 主频道/          # 主要分类排序字典
│   ├── CCTV.txt
│   ├── 卫视.txt
│   ├── 电影.txt
│   └── ...
└── 地方台/          # 地方台排序字典
    ├── 北京.txt
    ├── 上海.txt
    └── ...
```

文件格式

```txt
# assets/livesource/主频道/CCTV.txt
# 按数字顺序排列，特殊频道单独处理
CCTV-1
CCTV-2
CCTV-3
...
CCTV-13
CCTV-14
CCTV-15
CCTV-16
CCTV-17
CCTV-4K      # 4K频道放最后
CCTV-8K      # 8K频道最后
```

特殊排序规则

```txt
# assets/livesource/主频道/卫视.txt
# 按拼音首字母分组
北京卫视
重庆卫视
东方卫视
...
浙江卫视
湖南卫视
江苏卫视
```

3.2 自定义排序函数

如果需要特殊排序逻辑，可以修改 sort_data() 函数：

```python
def sort_data(order, data):
    """自定义排序函数"""
    order_dict = {name: i for i, name in enumerate(order)}
    
    def sort_key(line):
        name = line.split(',')[0]
        
        # 优先级1：是否在字典中
        if name in order_dict:
            return (0, order_dict[name])  # 在字典中，按字典顺序
        
        # 优先级2：按名称长度（短的名字优先）
        return (1, len(name), name)  # 不在字典中，按长度和字母排序
    
    return sorted(data, key=sort_key)
```

3.3 频道名称修正

3.3.1 修正字典文件

```txt
# assets/livesource/corrections_name.txt
# 格式：正确名称,别名1,别名2,别名3,...
CCTV-1,CCTV1,央视一套,央视1套,中央一台,中央一套
湖南卫视,湖南电视台,湖南台,芒果台
浙江卫视,浙江电视台,浙卫
BTV-北京,北京卫视,北京电视台,北京台
```

3.3.2 清理规则

```python
# removal_list 清理不需要的字符
removal_list = [
    "_电信", "电信", "频道", "频陆", "备陆",
    "高清", "超清", "标清",  # 画质标识
    "HD", "4K", "8K",       # 分辨率标识
    "「回看」", "「IPV4」", "「IPV6」",  # 特殊标识
    # 可以添加或删除清理词
]
```

3.4 特殊分类排序

3.4.1 体育赛事特殊排序

```python
def custom_tyss_sort(lines):
    """体育赛事排序：日期倒序 + 其他正序"""
    digit_prefix = []  # 数字开头的（日期）
    others = []        # 其他
    
    for line in lines:
        name_part = line.split(',')[0].strip()
        if name_part and name_part[0].isdigit():
            digit_prefix.append(line)
        else:
            others.append(line)
    
    # 日期倒序（最新的在前）
    digit_prefix_sorted = sorted(digit_prefix, reverse=True)
    # 其他按字母正序
    others_sorted = sorted(others)
    
    return digit_prefix_sorted + others_sorted
```

3.4.2 央视特殊处理

```python
def process_name_string(input_str):
    """处理央视频道名称"""
    parts = input_str.split(',')
    processed_parts = []
    for part in parts:
        if "CCTV" in part and "://" not in part:
            # 清理央视名称
            part = part.replace("IPV6", "").replace("PLUS", "+")
            # 保留数字和K
            filtered = ''.join(char for char in part if char.isdigit() or char in 'K+')
            if filtered:
                part = "CCTV" + filtered
        processed_parts.append(part)
    return ','.join(processed_parts)
```

---

4. 格式配置

4.1 输出文件格式

4.1.1 TXT格式（主格式）

```txt
# 格式：频道名称,播放地址
# 分组：#genre#
🌐央视频道,#genre#
CCTV-1,http://example.com/cctv1
CCTV-2,http://example.com/cctv2
```

4.1.2 M3U格式（兼容格式）

```m3u
#EXTM3U x-tvg-url="https://live.fanmingming.cn/e.xml"
#EXTINF:-1 group-title="🌐央视频道",CCTV-1
http://example.com/cctv1
#EXTINF:-1 group-title="🌐央视频道",CCTV-2
http://example.com/cctv2
```

4.2 修改M3U格式

4.2.1 修改EPG源

```python
def make_m3u(txt_file, m3u_file):
    output_text = '#EXTM3U '
    
    # 选择EPG源（三选一）
    # 1. 枫枫EPG
    output_text += 'x-tvg-url="https://live.fanmingming.cn/e.xml"'
    # 2. 51ZMT EPG
    # output_text += 'x-tvg-url="http://epg.51zmt.top:8000/e.xml"'
    # 3. 自定义EPG
    # output_text += 'x-tvg-url="http://your-epg-server.com/e.xml"'
    
    output_text += '\n'
    # ... 其余代码
```

4.2.2 添加Logo支持

```python
# 需要先准备 logo.txt 文件
# 格式：频道名称,LogoURL
CCTV-1,http://example.com/logo/cctv1.png
湖南卫视,http://example.com/logo/hunan.png

# 在make_m3u函数中自动应用
if logo_url:
    output_text += f'#EXTINF:-1 tvg-name="{channel_name}" tvg-logo="{logo_url}" group-title="{group_name}",{channel_name}\n'
else:
    output_text += f'#EXTINF:-1 group-title="{group_name}",{channel_name}\n'
```

4.3 自定义输出内容

4.3.1 添加自定义头部

```python
# 在 build_playlist() 函数开头添加
def build_playlist(playlist_type="full"):
    all_lines = []
    
    # 添加自定义头部信息
    if playlist_type == "full":
        all_lines.append("# 直播源聚合 v2.00")
        all_lines.append(f"# 生成时间: {get_beijing_time().strftime('%Y-%m-%d %H:%M:%S')}")
        all_lines.append("# 项目地址: https://github.com/your/repo")
        all_lines.append("")
    
    # ... 其余代码
```

4.3.2 添加分类统计

```python
# 在每个分类后添加统计信息
if processed_data:
    all_lines.append(f"{emoji}{category_name},#genre#")
    all_lines.extend(processed_data)
    # 添加统计信息（注释行）
    all_lines.append(f"# 本组共 {len(processed_data)} 个频道")
    all_lines.append('\n')
```

---

5. 数据源管理

5.1 URL源配置

5.1.1 主URL列表

```txt
# assets/livesource/urls-daily.txt
# 每日更新的源
http://example.com/daily1.m3u
http://example.com/daily2.txt

# 支持日期变量
http://example.com/直播源{MMdd}.m3u      # 当天日期
http://example.com/直播源{MMdd-1}.m3u    # 昨天日期
```

5.1.2 手工维护源

```
assets/livesource/手工区/
├── 优质央视.txt      # 高质量央视源
├── 优质卫视.txt      # 高质量卫视源
├── sports.txt       # 体育频道
├── 浙江频道.txt      # 浙江地方台
├── 广东频道.txt      # 广东地方台
├── 今日推荐.txt      # 推荐源
└── about.txt        # 关于信息
```

5.2 黑白名单管理

5.2.1 黑名单配置

```txt
# assets/livesource/blacklist/blacklist_auto.txt
# 格式：时间戳,URL,原因
20240101,http://bad-url.com/live,失效
20240101,http://spam.com/tv,广告
```

5.2.2 白名单配置

```txt
# assets/livesource/blacklist/whitelist_auto.txt
# 格式：响应时间,频道名称,URL
12ms,CCTV-1,http://good-url.com/cctv1
25ms,湖南卫视,http://good-url.com/hunan
```

5.3 数据质量控制

5.3.1 URL质量评分

```python
def score_url_quality(url):
    """URL质量评分规则"""
    score = 0
    
    # 协议安全性
    if url.startswith('https://'): score += 5
    elif url.startswith('http://'): score += 3
    
    # 域名可信度
    if '.com' in url or '.cn' in url: score += 2
    elif '.net' in url or '.org' in url: score += 1
    
    # URL简洁度
    if '?' not in url and '&' not in url: score += 2
    
    # 长度适宜度
    if len(url) < 100: score += 2
    elif len(url) < 200: score += 1
    
    return score
```

5.3.2 响应时间过滤

```python
# 在白名单处理中
if response_time < 2000:  # 2秒内响应
    process_channel_line(line)
```

---

6. 高级配置

6.1 配置文件方式（推荐）

6.1.1 创建配置文件

```json
{
    "version": "2.0",
    "categories": {
        "央视频道": {
            "enabled": true,
            "data_var": "yangshi_lines",
            "dict_file": "assets/livesource/主频道/CCTV.txt",
            "keep_multiple": true,
            "max_sources": 3,
            "sort_method": "dict_order",
            "emoji": "🌐",
            "priority": 1
        },
        "卫视频道": {
            "enabled": true,
            "data_var": "weishi_lines",
            "dict_file": "assets/livesource/主频道/卫视.txt",
            "keep_multiple": true,
            "max_sources": 3,
            "sort_method": "dict_order",
            "emoji": "📡",
            "priority": 2
        }
    },
    "output": {
        "epg_source": "https://live.fanmingming.cn/e.xml",
        "generate_m3u": true,
        "generate_html": true,
        "compress_output": false
    }
}
```

6.1.2 加载配置

```python
import json

def load_config():
    with open('config/settings.json', 'r', encoding='utf-8') as f:
        return json.load(f)

config = load_config()

# 应用配置
for cat_name, cat_config in config['categories'].items():
    if cat_config['enabled']:
        # 动态配置分类
        pass
```

6.2 插件化架构

6.2.1 创建插件目录

```
plugins/
├── __init__.py
├── cctv_processor.py      # 央视处理插件
├── sports_processor.py    # 体育处理插件
└── quality_filter.py      # 质量过滤插件
```

6.2.2 插件接口

```python
# plugins/base_plugin.py
class BasePlugin:
    def process_line(self, line):
        """处理单行数据"""
        pass
    
    def process_category(self, data):
        """处理整个分类"""
        pass
    
    def get_priority(self):
        """插件优先级"""
        return 0
```

6.3 性能优化配置

6.3.1 内存优化

```python
# 限制单分类最大频道数
MAX_CHANNELS_PER_CATEGORY = 500

def process_category_data(data_lines, ...):
    if len(data_lines) > MAX_CHANNELS_PER_CATEGORY:
        print(f"⚠️  {category_name} 频道数过多，进行抽样")
        data_lines = random.sample(data_lines, MAX_CHANNELS_PER_CATEGORY)
    # ... 处理逻辑
```

6.3.2 缓存机制

```python
import hashlib

def get_cache_key(data):
    """生成缓存键"""
    content = ''.join(data)
    return hashlib.md5(content.encode()).hexdigest()

# 缓存处理结果
cache = {}
if cache_key in cache:
    return cache[cache_key]
else:
    result = process_data(data)
    cache[cache_key] = result
    return result
```

---

7. 故障排除

7.1 常见问题

问题1：分类数据为空

```
✅ 央视频道: 0 个频道
```

原因：

1. 数据源中没有该分类的频道
2. 分类规则不匹配
3. 字典文件为空或格式错误

解决：

1. 检查数据源是否包含该分类
2. 调试分发逻辑
3. 验证字典文件格式

问题2：排序混乱

```
CCTV-10
CCTV-2
CCTV-1
```

原因： 字典文件顺序错误或缺失

解决：

1. 检查字典文件中的顺序
2. 确认频道名称匹配
3. 使用 correct_name_data() 修正名称

问题3：输出文件过大

原因： 重复数据过多或保留源过多

解决：

1. 调整 keep_multiple=False
2. 减少 max_sources=1
3. 加强去重逻辑

7.2 调试工具

7.2.1 调试模式

```python
# 在主程序开头添加
DEBUG_MODE = True

def debug_print(message):
    if DEBUG_MODE:
        print(f"[DEBUG] {message}")

# 在关键位置添加调试信息
debug_print(f"处理分类: {category_name}, 数据量: {len(data_lines)}")
```

7.2.2 数据验证

```python
def validate_category(category_name, data_lines):
    """验证分类数据"""
    print(f"\n🔍 验证分类: {category_name}")
    print(f"数据量: {len(data_lines)}")
    
    if data_lines:
        # 检查重复
        unique_lines = set(data_lines)
        duplicates = len(data_lines) - len(unique_lines)
        print(f"重复数: {duplicates}")
        
        # 显示样本
        print("样本 (前5个):")
        for i, line in enumerate(data_lines[:5]):
            print(f"  {i+1}. {line}")
    
    return len(data_lines) > 0
```

7.3 日志系统

7.3.1 配置日志

```python
import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/process.log'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)
```

7.3.2 使用日志

```python
logger.info(f"开始处理URL: {url}")
logger.warning(f"黑名单过滤: {channel_name}")
logger.error(f"处理错误: {e}")
```

---

8. 附录

8.1 Emoji图标参考

分类 Emoji 说明
央视频道 🌐 地球，表示全国覆盖
卫视频道 📡 卫星天线
地方台 🏙️/🏛️ 城市/建筑
港澳台 🇭🇰🇲🇴🇨🇳 地区旗帜
电影 🎬 电影场记板
体育 ⚽️🏀 运动项目
音乐 🎵 音符
动画 🐱 卡通动物

8.2 维护检查清单

每日维护

· 检查数据源可用性
· 更新黑白名单
· 验证输出文件
· 检查错误日志

每周维护

· 清理过期数据
· 更新分类字典
· 优化配置参数
· 备份配置文件

每月维护

· 审查分类结构
· 更新维护文档
· 性能优化调整
· 安全漏洞检查

8.3 联系与支持

· 项目地址: https://github.com/your/repo
· 问题反馈: 创建Issue
· 文档更新: 提交Pull Request
· 紧急联系: admin@example.com

---

📄 文档更新记录

版本 日期 更新内容 更新人
1.0 2025-01-01 初始版本 维护组
2.0 2025-02-02 全局去重 维护组
2.2 2024-02-01 重构为配置文件方式 维护组

---

⚠️ 注意事项：

1. 修改配置前请备份原文件
2. 测试环境验证后再上生产
3. 定期查看日志文件
4. 保持文档与代码同步更新

📞 如有问题，请参考文档或联系维护团队。